package org.xtext.example.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.services.TransformationDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalTransformationDSLParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'use'"
    };
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=6;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int RULE_INT=5;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalTransformationDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalTransformationDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalTransformationDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalTransformationDSL.g"; }


    	private TransformationDSLGrammarAccess grammarAccess;

    	public void setGrammarAccess(TransformationDSLGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalTransformationDSL.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalTransformationDSL.g:54:1: ( ruleModel EOF )
            // InternalTransformationDSL.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalTransformationDSL.g:62:1: ruleModel : ( ( rule__Model__GreetingsAssignment )* ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:66:2: ( ( ( rule__Model__GreetingsAssignment )* ) )
            // InternalTransformationDSL.g:67:2: ( ( rule__Model__GreetingsAssignment )* )
            {
            // InternalTransformationDSL.g:67:2: ( ( rule__Model__GreetingsAssignment )* )
            // InternalTransformationDSL.g:68:3: ( rule__Model__GreetingsAssignment )*
            {
             before(grammarAccess.getModelAccess().getGreetingsAssignment()); 
            // InternalTransformationDSL.g:69:3: ( rule__Model__GreetingsAssignment )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalTransformationDSL.g:69:4: rule__Model__GreetingsAssignment
            	    {
            	    pushFollow(FOLLOW_3);
            	    rule__Model__GreetingsAssignment();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getGreetingsAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleGreeting"
    // InternalTransformationDSL.g:78:1: entryRuleGreeting : ruleGreeting EOF ;
    public final void entryRuleGreeting() throws RecognitionException {
        try {
            // InternalTransformationDSL.g:79:1: ( ruleGreeting EOF )
            // InternalTransformationDSL.g:80:1: ruleGreeting EOF
            {
             before(grammarAccess.getGreetingRule()); 
            pushFollow(FOLLOW_1);
            ruleGreeting();

            state._fsp--;

             after(grammarAccess.getGreetingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGreeting"


    // $ANTLR start "ruleGreeting"
    // InternalTransformationDSL.g:87:1: ruleGreeting : ( ( rule__Greeting__Group__0 ) ) ;
    public final void ruleGreeting() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:91:2: ( ( ( rule__Greeting__Group__0 ) ) )
            // InternalTransformationDSL.g:92:2: ( ( rule__Greeting__Group__0 ) )
            {
            // InternalTransformationDSL.g:92:2: ( ( rule__Greeting__Group__0 ) )
            // InternalTransformationDSL.g:93:3: ( rule__Greeting__Group__0 )
            {
             before(grammarAccess.getGreetingAccess().getGroup()); 
            // InternalTransformationDSL.g:94:3: ( rule__Greeting__Group__0 )
            // InternalTransformationDSL.g:94:4: rule__Greeting__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Greeting__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGreetingAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGreeting"


    // $ANTLR start "entryRulecheck"
    // InternalTransformationDSL.g:103:1: entryRulecheck : rulecheck EOF ;
    public final void entryRulecheck() throws RecognitionException {
        try {
            // InternalTransformationDSL.g:104:1: ( rulecheck EOF )
            // InternalTransformationDSL.g:105:1: rulecheck EOF
            {
             before(grammarAccess.getCheckRule()); 
            pushFollow(FOLLOW_1);
            rulecheck();

            state._fsp--;

             after(grammarAccess.getCheckRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulecheck"


    // $ANTLR start "rulecheck"
    // InternalTransformationDSL.g:112:1: rulecheck : ( ( rule__Check__CheckAssignment ) ) ;
    public final void rulecheck() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:116:2: ( ( ( rule__Check__CheckAssignment ) ) )
            // InternalTransformationDSL.g:117:2: ( ( rule__Check__CheckAssignment ) )
            {
            // InternalTransformationDSL.g:117:2: ( ( rule__Check__CheckAssignment ) )
            // InternalTransformationDSL.g:118:3: ( rule__Check__CheckAssignment )
            {
             before(grammarAccess.getCheckAccess().getCheckAssignment()); 
            // InternalTransformationDSL.g:119:3: ( rule__Check__CheckAssignment )
            // InternalTransformationDSL.g:119:4: rule__Check__CheckAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Check__CheckAssignment();

            state._fsp--;


            }

             after(grammarAccess.getCheckAccess().getCheckAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulecheck"


    // $ANTLR start "rule__Greeting__Group__0"
    // InternalTransformationDSL.g:127:1: rule__Greeting__Group__0 : rule__Greeting__Group__0__Impl rule__Greeting__Group__1 ;
    public final void rule__Greeting__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:131:1: ( rule__Greeting__Group__0__Impl rule__Greeting__Group__1 )
            // InternalTransformationDSL.g:132:2: rule__Greeting__Group__0__Impl rule__Greeting__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Greeting__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Greeting__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__Group__0"


    // $ANTLR start "rule__Greeting__Group__0__Impl"
    // InternalTransformationDSL.g:139:1: rule__Greeting__Group__0__Impl : ( 'use' ) ;
    public final void rule__Greeting__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:143:1: ( ( 'use' ) )
            // InternalTransformationDSL.g:144:1: ( 'use' )
            {
            // InternalTransformationDSL.g:144:1: ( 'use' )
            // InternalTransformationDSL.g:145:2: 'use'
            {
             before(grammarAccess.getGreetingAccess().getUseKeyword_0()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getGreetingAccess().getUseKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__Group__0__Impl"


    // $ANTLR start "rule__Greeting__Group__1"
    // InternalTransformationDSL.g:154:1: rule__Greeting__Group__1 : rule__Greeting__Group__1__Impl rule__Greeting__Group__2 ;
    public final void rule__Greeting__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:158:1: ( rule__Greeting__Group__1__Impl rule__Greeting__Group__2 )
            // InternalTransformationDSL.g:159:2: rule__Greeting__Group__1__Impl rule__Greeting__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Greeting__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Greeting__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__Group__1"


    // $ANTLR start "rule__Greeting__Group__1__Impl"
    // InternalTransformationDSL.g:166:1: rule__Greeting__Group__1__Impl : ( ( rule__Greeting__DefinitionAssignment_1 ) ) ;
    public final void rule__Greeting__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:170:1: ( ( ( rule__Greeting__DefinitionAssignment_1 ) ) )
            // InternalTransformationDSL.g:171:1: ( ( rule__Greeting__DefinitionAssignment_1 ) )
            {
            // InternalTransformationDSL.g:171:1: ( ( rule__Greeting__DefinitionAssignment_1 ) )
            // InternalTransformationDSL.g:172:2: ( rule__Greeting__DefinitionAssignment_1 )
            {
             before(grammarAccess.getGreetingAccess().getDefinitionAssignment_1()); 
            // InternalTransformationDSL.g:173:2: ( rule__Greeting__DefinitionAssignment_1 )
            // InternalTransformationDSL.g:173:3: rule__Greeting__DefinitionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Greeting__DefinitionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGreetingAccess().getDefinitionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__Group__1__Impl"


    // $ANTLR start "rule__Greeting__Group__2"
    // InternalTransformationDSL.g:181:1: rule__Greeting__Group__2 : rule__Greeting__Group__2__Impl ;
    public final void rule__Greeting__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:185:1: ( rule__Greeting__Group__2__Impl )
            // InternalTransformationDSL.g:186:2: rule__Greeting__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Greeting__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__Group__2"


    // $ANTLR start "rule__Greeting__Group__2__Impl"
    // InternalTransformationDSL.g:192:1: rule__Greeting__Group__2__Impl : ( ( rule__Greeting__CheckAssignment_2 ) ) ;
    public final void rule__Greeting__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:196:1: ( ( ( rule__Greeting__CheckAssignment_2 ) ) )
            // InternalTransformationDSL.g:197:1: ( ( rule__Greeting__CheckAssignment_2 ) )
            {
            // InternalTransformationDSL.g:197:1: ( ( rule__Greeting__CheckAssignment_2 ) )
            // InternalTransformationDSL.g:198:2: ( rule__Greeting__CheckAssignment_2 )
            {
             before(grammarAccess.getGreetingAccess().getCheckAssignment_2()); 
            // InternalTransformationDSL.g:199:2: ( rule__Greeting__CheckAssignment_2 )
            // InternalTransformationDSL.g:199:3: rule__Greeting__CheckAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Greeting__CheckAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getGreetingAccess().getCheckAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__Group__2__Impl"


    // $ANTLR start "rule__Model__GreetingsAssignment"
    // InternalTransformationDSL.g:208:1: rule__Model__GreetingsAssignment : ( ruleGreeting ) ;
    public final void rule__Model__GreetingsAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:212:1: ( ( ruleGreeting ) )
            // InternalTransformationDSL.g:213:2: ( ruleGreeting )
            {
            // InternalTransformationDSL.g:213:2: ( ruleGreeting )
            // InternalTransformationDSL.g:214:3: ruleGreeting
            {
             before(grammarAccess.getModelAccess().getGreetingsGreetingParserRuleCall_0()); 
            pushFollow(FOLLOW_2);
            ruleGreeting();

            state._fsp--;

             after(grammarAccess.getModelAccess().getGreetingsGreetingParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__GreetingsAssignment"


    // $ANTLR start "rule__Greeting__DefinitionAssignment_1"
    // InternalTransformationDSL.g:223:1: rule__Greeting__DefinitionAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__Greeting__DefinitionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:227:1: ( ( ( RULE_ID ) ) )
            // InternalTransformationDSL.g:228:2: ( ( RULE_ID ) )
            {
            // InternalTransformationDSL.g:228:2: ( ( RULE_ID ) )
            // InternalTransformationDSL.g:229:3: ( RULE_ID )
            {
             before(grammarAccess.getGreetingAccess().getDefinitionLibraryBusinessMethodStatementCrossReference_1_0()); 
            // InternalTransformationDSL.g:230:3: ( RULE_ID )
            // InternalTransformationDSL.g:231:4: RULE_ID
            {
             before(grammarAccess.getGreetingAccess().getDefinitionLibraryBusinessMethodStatementIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getGreetingAccess().getDefinitionLibraryBusinessMethodStatementIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getGreetingAccess().getDefinitionLibraryBusinessMethodStatementCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__DefinitionAssignment_1"


    // $ANTLR start "rule__Greeting__CheckAssignment_2"
    // InternalTransformationDSL.g:242:1: rule__Greeting__CheckAssignment_2 : ( rulecheck ) ;
    public final void rule__Greeting__CheckAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:246:1: ( ( rulecheck ) )
            // InternalTransformationDSL.g:247:2: ( rulecheck )
            {
            // InternalTransformationDSL.g:247:2: ( rulecheck )
            // InternalTransformationDSL.g:248:3: rulecheck
            {
             before(grammarAccess.getGreetingAccess().getCheckCheckParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            rulecheck();

            state._fsp--;

             after(grammarAccess.getGreetingAccess().getCheckCheckParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Greeting__CheckAssignment_2"


    // $ANTLR start "rule__Check__CheckAssignment"
    // InternalTransformationDSL.g:257:1: rule__Check__CheckAssignment : ( ( RULE_ID ) ) ;
    public final void rule__Check__CheckAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalTransformationDSL.g:261:1: ( ( ( RULE_ID ) ) )
            // InternalTransformationDSL.g:262:2: ( ( RULE_ID ) )
            {
            // InternalTransformationDSL.g:262:2: ( ( RULE_ID ) )
            // InternalTransformationDSL.g:263:3: ( RULE_ID )
            {
             before(grammarAccess.getCheckAccess().getCheckClassOperationStatementCrossReference_0()); 
            // InternalTransformationDSL.g:264:3: ( RULE_ID )
            // InternalTransformationDSL.g:265:4: RULE_ID
            {
             before(grammarAccess.getCheckAccess().getCheckClassOperationStatementIDTerminalRuleCall_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getCheckAccess().getCheckClassOperationStatementIDTerminalRuleCall_0_1()); 

            }

             after(grammarAccess.getCheckAccess().getCheckClassOperationStatementCrossReference_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Check__CheckAssignment"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});

}