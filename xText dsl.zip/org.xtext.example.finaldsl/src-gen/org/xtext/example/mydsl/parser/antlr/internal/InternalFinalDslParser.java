package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.FinalDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalFinalDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'functionName'", "'functionElement'", "'('", "')'", "'if'", "'{'", "'}'", "'else'", "'for'", "'parameter'", "','", "'ClassAttribute'", "'ClassOperation'", "'OperationParameter'", "'not'", "'notIn'", "'(('", "'))'", "'CreateInstance'", "'Log'", "'Hash'", "'Message'", "'Error'", "'>'", "'<>'", "'<'", "'=>'", "'<='", "'='", "'in'", "'+'", "'-'", "'OR'", "'*'", "'/'", "'AND'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalFinalDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalFinalDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalFinalDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalFinalDsl.g"; }



     	private FinalDslGrammarAccess grammarAccess;

        public InternalFinalDslParser(TokenStream input, FinalDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected FinalDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalFinalDsl.g:65:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalFinalDsl.g:65:46: (iv_ruleModel= ruleModel EOF )
            // InternalFinalDsl.g:66:2: iv_ruleModel= ruleModel EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getModelRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleModel; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalFinalDsl.g:72:1: ruleModel returns [EObject current=null] : (otherlv_0= 'functionName' ( (lv_name_1_0= RULE_STRING ) ) ( (lv_functions_2_0= ruleFunctionElement ) )* ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_functions_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:78:2: ( (otherlv_0= 'functionName' ( (lv_name_1_0= RULE_STRING ) ) ( (lv_functions_2_0= ruleFunctionElement ) )* ) )
            // InternalFinalDsl.g:79:2: (otherlv_0= 'functionName' ( (lv_name_1_0= RULE_STRING ) ) ( (lv_functions_2_0= ruleFunctionElement ) )* )
            {
            // InternalFinalDsl.g:79:2: (otherlv_0= 'functionName' ( (lv_name_1_0= RULE_STRING ) ) ( (lv_functions_2_0= ruleFunctionElement ) )* )
            // InternalFinalDsl.g:80:3: otherlv_0= 'functionName' ( (lv_name_1_0= RULE_STRING ) ) ( (lv_functions_2_0= ruleFunctionElement ) )*
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getModelAccess().getFunctionNameKeyword_0());
              		
            }
            // InternalFinalDsl.g:84:3: ( (lv_name_1_0= RULE_STRING ) )
            // InternalFinalDsl.g:85:4: (lv_name_1_0= RULE_STRING )
            {
            // InternalFinalDsl.g:85:4: (lv_name_1_0= RULE_STRING )
            // InternalFinalDsl.g:86:5: lv_name_1_0= RULE_STRING
            {
            lv_name_1_0=(Token)match(input,RULE_STRING,FOLLOW_4); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_name_1_0, grammarAccess.getModelAccess().getNameSTRINGTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getModelRule());
              					}
              					setWithLastConsumed(
              						current,
              						"name",
              						lv_name_1_0,
              						"org.eclipse.xtext.common.Terminals.STRING");
              				
            }

            }


            }

            // InternalFinalDsl.g:102:3: ( (lv_functions_2_0= ruleFunctionElement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==12) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalFinalDsl.g:103:4: (lv_functions_2_0= ruleFunctionElement )
            	    {
            	    // InternalFinalDsl.g:103:4: (lv_functions_2_0= ruleFunctionElement )
            	    // InternalFinalDsl.g:104:5: lv_functions_2_0= ruleFunctionElement
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getModelAccess().getFunctionsFunctionElementParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_4);
            	    lv_functions_2_0=ruleFunctionElement();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getModelRule());
            	      					}
            	      					add(
            	      						current,
            	      						"functions",
            	      						lv_functions_2_0,
            	      						"org.xtext.example.mydsl.FinalDsl.FunctionElement");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleFunctionElement"
    // InternalFinalDsl.g:125:1: entryRuleFunctionElement returns [EObject current=null] : iv_ruleFunctionElement= ruleFunctionElement EOF ;
    public final EObject entryRuleFunctionElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFunctionElement = null;


        try {
            // InternalFinalDsl.g:125:56: (iv_ruleFunctionElement= ruleFunctionElement EOF )
            // InternalFinalDsl.g:126:2: iv_ruleFunctionElement= ruleFunctionElement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFunctionElementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFunctionElement=ruleFunctionElement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFunctionElement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFunctionElement"


    // $ANTLR start "ruleFunctionElement"
    // InternalFinalDsl.g:132:1: ruleFunctionElement returns [EObject current=null] : (otherlv_0= 'functionElement' ( (lv_name_1_0= RULE_ID ) ) ( (lv_statements_2_0= ruleStatementSequence ) )+ ) ;
    public final EObject ruleFunctionElement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        EObject lv_statements_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:138:2: ( (otherlv_0= 'functionElement' ( (lv_name_1_0= RULE_ID ) ) ( (lv_statements_2_0= ruleStatementSequence ) )+ ) )
            // InternalFinalDsl.g:139:2: (otherlv_0= 'functionElement' ( (lv_name_1_0= RULE_ID ) ) ( (lv_statements_2_0= ruleStatementSequence ) )+ )
            {
            // InternalFinalDsl.g:139:2: (otherlv_0= 'functionElement' ( (lv_name_1_0= RULE_ID ) ) ( (lv_statements_2_0= ruleStatementSequence ) )+ )
            // InternalFinalDsl.g:140:3: otherlv_0= 'functionElement' ( (lv_name_1_0= RULE_ID ) ) ( (lv_statements_2_0= ruleStatementSequence ) )+
            {
            otherlv_0=(Token)match(input,12,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getFunctionElementAccess().getFunctionElementKeyword_0());
              		
            }
            // InternalFinalDsl.g:144:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalFinalDsl.g:145:4: (lv_name_1_0= RULE_ID )
            {
            // InternalFinalDsl.g:145:4: (lv_name_1_0= RULE_ID )
            // InternalFinalDsl.g:146:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_name_1_0, grammarAccess.getFunctionElementAccess().getNameIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getFunctionElementRule());
              					}
              					setWithLastConsumed(
              						current,
              						"name",
              						lv_name_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }

            // InternalFinalDsl.g:162:3: ( (lv_statements_2_0= ruleStatementSequence ) )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==13||LA2_0==15||LA2_0==19||LA2_0==23||(LA2_0>=29 && LA2_0<=33)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalFinalDsl.g:163:4: (lv_statements_2_0= ruleStatementSequence )
            	    {
            	    // InternalFinalDsl.g:163:4: (lv_statements_2_0= ruleStatementSequence )
            	    // InternalFinalDsl.g:164:5: lv_statements_2_0= ruleStatementSequence
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getFunctionElementAccess().getStatementsStatementSequenceParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_7);
            	    lv_statements_2_0=ruleStatementSequence();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getFunctionElementRule());
            	      					}
            	      					add(
            	      						current,
            	      						"statements",
            	      						lv_statements_2_0,
            	      						"org.xtext.example.mydsl.FinalDsl.StatementSequence");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFunctionElement"


    // $ANTLR start "entryRuleStatementSequence"
    // InternalFinalDsl.g:185:1: entryRuleStatementSequence returns [EObject current=null] : iv_ruleStatementSequence= ruleStatementSequence EOF ;
    public final EObject entryRuleStatementSequence() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatementSequence = null;


        try {
            // InternalFinalDsl.g:185:58: (iv_ruleStatementSequence= ruleStatementSequence EOF )
            // InternalFinalDsl.g:186:2: iv_ruleStatementSequence= ruleStatementSequence EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStatementSequenceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStatementSequence=ruleStatementSequence();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStatementSequence; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatementSequence"


    // $ANTLR start "ruleStatementSequence"
    // InternalFinalDsl.g:192:1: ruleStatementSequence returns [EObject current=null] : ( (lv_statement_0_0= ruleStatement ) ) ;
    public final EObject ruleStatementSequence() throws RecognitionException {
        EObject current = null;

        EObject lv_statement_0_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:198:2: ( ( (lv_statement_0_0= ruleStatement ) ) )
            // InternalFinalDsl.g:199:2: ( (lv_statement_0_0= ruleStatement ) )
            {
            // InternalFinalDsl.g:199:2: ( (lv_statement_0_0= ruleStatement ) )
            // InternalFinalDsl.g:200:3: (lv_statement_0_0= ruleStatement )
            {
            // InternalFinalDsl.g:200:3: (lv_statement_0_0= ruleStatement )
            // InternalFinalDsl.g:201:4: lv_statement_0_0= ruleStatement
            {
            if ( state.backtracking==0 ) {

              				newCompositeNode(grammarAccess.getStatementSequenceAccess().getStatementStatementParserRuleCall_0());
              			
            }
            pushFollow(FOLLOW_2);
            lv_statement_0_0=ruleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElementForParent(grammarAccess.getStatementSequenceRule());
              				}
              				set(
              					current,
              					"statement",
              					lv_statement_0_0,
              					"org.xtext.example.mydsl.FinalDsl.Statement");
              				afterParserOrEnumRuleCall();
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatementSequence"


    // $ANTLR start "entryRuleStatement"
    // InternalFinalDsl.g:221:1: entryRuleStatement returns [EObject current=null] : iv_ruleStatement= ruleStatement EOF ;
    public final EObject entryRuleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatement = null;


        try {
            // InternalFinalDsl.g:221:50: (iv_ruleStatement= ruleStatement EOF )
            // InternalFinalDsl.g:222:2: iv_ruleStatement= ruleStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStatement=ruleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalFinalDsl.g:228:1: ruleStatement returns [EObject current=null] : (this_CompoundStatement_0= ruleCompoundStatement | this_SimpleStatement_1= ruleSimpleStatement | this_StructuredStatement_2= ruleStructuredStatement ) ;
    public final EObject ruleStatement() throws RecognitionException {
        EObject current = null;

        EObject this_CompoundStatement_0 = null;

        EObject this_SimpleStatement_1 = null;

        EObject this_StructuredStatement_2 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:234:2: ( (this_CompoundStatement_0= ruleCompoundStatement | this_SimpleStatement_1= ruleSimpleStatement | this_StructuredStatement_2= ruleStructuredStatement ) )
            // InternalFinalDsl.g:235:2: (this_CompoundStatement_0= ruleCompoundStatement | this_SimpleStatement_1= ruleSimpleStatement | this_StructuredStatement_2= ruleStructuredStatement )
            {
            // InternalFinalDsl.g:235:2: (this_CompoundStatement_0= ruleCompoundStatement | this_SimpleStatement_1= ruleSimpleStatement | this_StructuredStatement_2= ruleStructuredStatement )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt3=1;
                }
                break;
            case 23:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
                {
                alt3=2;
                }
                break;
            case 15:
            case 19:
                {
                alt3=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalFinalDsl.g:236:3: this_CompoundStatement_0= ruleCompoundStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStatementAccess().getCompoundStatementParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_CompoundStatement_0=ruleCompoundStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_CompoundStatement_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:245:3: this_SimpleStatement_1= ruleSimpleStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStatementAccess().getSimpleStatementParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_SimpleStatement_1=ruleSimpleStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_SimpleStatement_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:254:3: this_StructuredStatement_2= ruleStructuredStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStatementAccess().getStructuredStatementParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_StructuredStatement_2=ruleStructuredStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_StructuredStatement_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleSimpleStatement"
    // InternalFinalDsl.g:266:1: entryRuleSimpleStatement returns [EObject current=null] : iv_ruleSimpleStatement= ruleSimpleStatement EOF ;
    public final EObject entryRuleSimpleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSimpleStatement = null;


        try {
            // InternalFinalDsl.g:266:56: (iv_ruleSimpleStatement= ruleSimpleStatement EOF )
            // InternalFinalDsl.g:267:2: iv_ruleSimpleStatement= ruleSimpleStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSimpleStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSimpleStatement=ruleSimpleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSimpleStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSimpleStatement"


    // $ANTLR start "ruleSimpleStatement"
    // InternalFinalDsl.g:273:1: ruleSimpleStatement returns [EObject current=null] : (this_ClassOperationStatement_0= ruleClassOperationStatement | this_LibraryInterFaceMethodStatement_1= ruleLibraryInterFaceMethodStatement | this_LibraryPersistenceMethodStatement_2= ruleLibraryPersistenceMethodStatement | this_LibraryBusinessMethodStatement_3= ruleLibraryBusinessMethodStatement ) ;
    public final EObject ruleSimpleStatement() throws RecognitionException {
        EObject current = null;

        EObject this_ClassOperationStatement_0 = null;

        EObject this_LibraryInterFaceMethodStatement_1 = null;

        EObject this_LibraryPersistenceMethodStatement_2 = null;

        EObject this_LibraryBusinessMethodStatement_3 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:279:2: ( (this_ClassOperationStatement_0= ruleClassOperationStatement | this_LibraryInterFaceMethodStatement_1= ruleLibraryInterFaceMethodStatement | this_LibraryPersistenceMethodStatement_2= ruleLibraryPersistenceMethodStatement | this_LibraryBusinessMethodStatement_3= ruleLibraryBusinessMethodStatement ) )
            // InternalFinalDsl.g:280:2: (this_ClassOperationStatement_0= ruleClassOperationStatement | this_LibraryInterFaceMethodStatement_1= ruleLibraryInterFaceMethodStatement | this_LibraryPersistenceMethodStatement_2= ruleLibraryPersistenceMethodStatement | this_LibraryBusinessMethodStatement_3= ruleLibraryBusinessMethodStatement )
            {
            // InternalFinalDsl.g:280:2: (this_ClassOperationStatement_0= ruleClassOperationStatement | this_LibraryInterFaceMethodStatement_1= ruleLibraryInterFaceMethodStatement | this_LibraryPersistenceMethodStatement_2= ruleLibraryPersistenceMethodStatement | this_LibraryBusinessMethodStatement_3= ruleLibraryBusinessMethodStatement )
            int alt4=4;
            switch ( input.LA(1) ) {
            case 23:
                {
                alt4=1;
                }
                break;
            case 32:
            case 33:
                {
                alt4=2;
                }
                break;
            case 29:
            case 30:
                {
                alt4=3;
                }
                break;
            case 31:
                {
                alt4=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalFinalDsl.g:281:3: this_ClassOperationStatement_0= ruleClassOperationStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getSimpleStatementAccess().getClassOperationStatementParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ClassOperationStatement_0=ruleClassOperationStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ClassOperationStatement_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:290:3: this_LibraryInterFaceMethodStatement_1= ruleLibraryInterFaceMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getSimpleStatementAccess().getLibraryInterFaceMethodStatementParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LibraryInterFaceMethodStatement_1=ruleLibraryInterFaceMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LibraryInterFaceMethodStatement_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:299:3: this_LibraryPersistenceMethodStatement_2= ruleLibraryPersistenceMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getSimpleStatementAccess().getLibraryPersistenceMethodStatementParserRuleCall_2());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LibraryPersistenceMethodStatement_2=ruleLibraryPersistenceMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LibraryPersistenceMethodStatement_2;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 4 :
                    // InternalFinalDsl.g:308:3: this_LibraryBusinessMethodStatement_3= ruleLibraryBusinessMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getSimpleStatementAccess().getLibraryBusinessMethodStatementParserRuleCall_3());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_LibraryBusinessMethodStatement_3=ruleLibraryBusinessMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_LibraryBusinessMethodStatement_3;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSimpleStatement"


    // $ANTLR start "entryRuleStructuredStatement"
    // InternalFinalDsl.g:320:1: entryRuleStructuredStatement returns [EObject current=null] : iv_ruleStructuredStatement= ruleStructuredStatement EOF ;
    public final EObject entryRuleStructuredStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStructuredStatement = null;


        try {
            // InternalFinalDsl.g:320:60: (iv_ruleStructuredStatement= ruleStructuredStatement EOF )
            // InternalFinalDsl.g:321:2: iv_ruleStructuredStatement= ruleStructuredStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getStructuredStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleStructuredStatement=ruleStructuredStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleStructuredStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStructuredStatement"


    // $ANTLR start "ruleStructuredStatement"
    // InternalFinalDsl.g:327:1: ruleStructuredStatement returns [EObject current=null] : (this_ForLoops_0= ruleForLoops | this_IfElseStatements_1= ruleIfElseStatements ) ;
    public final EObject ruleStructuredStatement() throws RecognitionException {
        EObject current = null;

        EObject this_ForLoops_0 = null;

        EObject this_IfElseStatements_1 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:333:2: ( (this_ForLoops_0= ruleForLoops | this_IfElseStatements_1= ruleIfElseStatements ) )
            // InternalFinalDsl.g:334:2: (this_ForLoops_0= ruleForLoops | this_IfElseStatements_1= ruleIfElseStatements )
            {
            // InternalFinalDsl.g:334:2: (this_ForLoops_0= ruleForLoops | this_IfElseStatements_1= ruleIfElseStatements )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==19) ) {
                alt5=1;
            }
            else if ( (LA5_0==15) ) {
                alt5=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalFinalDsl.g:335:3: this_ForLoops_0= ruleForLoops
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructuredStatementAccess().getForLoopsParserRuleCall_0());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_ForLoops_0=ruleForLoops();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_ForLoops_0;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:344:3: this_IfElseStatements_1= ruleIfElseStatements
                    {
                    if ( state.backtracking==0 ) {

                      			newCompositeNode(grammarAccess.getStructuredStatementAccess().getIfElseStatementsParserRuleCall_1());
                      		
                    }
                    pushFollow(FOLLOW_2);
                    this_IfElseStatements_1=ruleIfElseStatements();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      			current = this_IfElseStatements_1;
                      			afterParserOrEnumRuleCall();
                      		
                    }

                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStructuredStatement"


    // $ANTLR start "entryRuleCompoundStatement"
    // InternalFinalDsl.g:356:1: entryRuleCompoundStatement returns [EObject current=null] : iv_ruleCompoundStatement= ruleCompoundStatement EOF ;
    public final EObject entryRuleCompoundStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompoundStatement = null;


        try {
            // InternalFinalDsl.g:356:58: (iv_ruleCompoundStatement= ruleCompoundStatement EOF )
            // InternalFinalDsl.g:357:2: iv_ruleCompoundStatement= ruleCompoundStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getCompoundStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleCompoundStatement=ruleCompoundStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleCompoundStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompoundStatement"


    // $ANTLR start "ruleCompoundStatement"
    // InternalFinalDsl.g:363:1: ruleCompoundStatement returns [EObject current=null] : (otherlv_0= '(' ( (lv_statements_1_0= ruleStatementSequence ) )+ otherlv_2= ')' ) ;
    public final EObject ruleCompoundStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_statements_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:369:2: ( (otherlv_0= '(' ( (lv_statements_1_0= ruleStatementSequence ) )+ otherlv_2= ')' ) )
            // InternalFinalDsl.g:370:2: (otherlv_0= '(' ( (lv_statements_1_0= ruleStatementSequence ) )+ otherlv_2= ')' )
            {
            // InternalFinalDsl.g:370:2: (otherlv_0= '(' ( (lv_statements_1_0= ruleStatementSequence ) )+ otherlv_2= ')' )
            // InternalFinalDsl.g:371:3: otherlv_0= '(' ( (lv_statements_1_0= ruleStatementSequence ) )+ otherlv_2= ')'
            {
            otherlv_0=(Token)match(input,13,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getCompoundStatementAccess().getLeftParenthesisKeyword_0());
              		
            }
            // InternalFinalDsl.g:375:3: ( (lv_statements_1_0= ruleStatementSequence ) )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==13||LA6_0==15||LA6_0==19||LA6_0==23||(LA6_0>=29 && LA6_0<=33)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalFinalDsl.g:376:4: (lv_statements_1_0= ruleStatementSequence )
            	    {
            	    // InternalFinalDsl.g:376:4: (lv_statements_1_0= ruleStatementSequence )
            	    // InternalFinalDsl.g:377:5: lv_statements_1_0= ruleStatementSequence
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getCompoundStatementAccess().getStatementsStatementSequenceParserRuleCall_1_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_8);
            	    lv_statements_1_0=ruleStatementSequence();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getCompoundStatementRule());
            	      					}
            	      					add(
            	      						current,
            	      						"statements",
            	      						lv_statements_1_0,
            	      						"org.xtext.example.mydsl.FinalDsl.StatementSequence");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);

            otherlv_2=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_2, grammarAccess.getCompoundStatementAccess().getRightParenthesisKeyword_2());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompoundStatement"


    // $ANTLR start "entryRuleIfElseStatements"
    // InternalFinalDsl.g:402:1: entryRuleIfElseStatements returns [EObject current=null] : iv_ruleIfElseStatements= ruleIfElseStatements EOF ;
    public final EObject entryRuleIfElseStatements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfElseStatements = null;


        try {
            // InternalFinalDsl.g:402:57: (iv_ruleIfElseStatements= ruleIfElseStatements EOF )
            // InternalFinalDsl.g:403:2: iv_ruleIfElseStatements= ruleIfElseStatements EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getIfElseStatementsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleIfElseStatements=ruleIfElseStatements();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleIfElseStatements; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfElseStatements"


    // $ANTLR start "ruleIfElseStatements"
    // InternalFinalDsl.g:409:1: ruleIfElseStatements returns [EObject current=null] : ( ( (lv_ifStatements_0_0= ruleIfStatements ) ) ( ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement ) )? ) ;
    public final EObject ruleIfElseStatements() throws RecognitionException {
        EObject current = null;

        EObject lv_ifStatements_0_0 = null;

        EObject lv_elseStatement_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:415:2: ( ( ( (lv_ifStatements_0_0= ruleIfStatements ) ) ( ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement ) )? ) )
            // InternalFinalDsl.g:416:2: ( ( (lv_ifStatements_0_0= ruleIfStatements ) ) ( ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement ) )? )
            {
            // InternalFinalDsl.g:416:2: ( ( (lv_ifStatements_0_0= ruleIfStatements ) ) ( ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement ) )? )
            // InternalFinalDsl.g:417:3: ( (lv_ifStatements_0_0= ruleIfStatements ) ) ( ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement ) )?
            {
            // InternalFinalDsl.g:417:3: ( (lv_ifStatements_0_0= ruleIfStatements ) )
            // InternalFinalDsl.g:418:4: (lv_ifStatements_0_0= ruleIfStatements )
            {
            // InternalFinalDsl.g:418:4: (lv_ifStatements_0_0= ruleIfStatements )
            // InternalFinalDsl.g:419:5: lv_ifStatements_0_0= ruleIfStatements
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getIfElseStatementsAccess().getIfStatementsIfStatementsParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_9);
            lv_ifStatements_0_0=ruleIfStatements();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getIfElseStatementsRule());
              					}
              					set(
              						current,
              						"ifStatements",
              						lv_ifStatements_0_0,
              						"org.xtext.example.mydsl.FinalDsl.IfStatements");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:436:3: ( ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==18) && (synpred1_InternalFinalDsl())) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalFinalDsl.g:437:4: ( 'else' )=> (lv_elseStatement_1_0= ruleElseStatement )
                    {
                    // InternalFinalDsl.g:438:4: (lv_elseStatement_1_0= ruleElseStatement )
                    // InternalFinalDsl.g:439:5: lv_elseStatement_1_0= ruleElseStatement
                    {
                    if ( state.backtracking==0 ) {

                      					newCompositeNode(grammarAccess.getIfElseStatementsAccess().getElseStatementElseStatementParserRuleCall_1_0());
                      				
                    }
                    pushFollow(FOLLOW_2);
                    lv_elseStatement_1_0=ruleElseStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					if (current==null) {
                      						current = createModelElementForParent(grammarAccess.getIfElseStatementsRule());
                      					}
                      					set(
                      						current,
                      						"elseStatement",
                      						lv_elseStatement_1_0,
                      						"org.xtext.example.mydsl.FinalDsl.ElseStatement");
                      					afterParserOrEnumRuleCall();
                      				
                    }

                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfElseStatements"


    // $ANTLR start "entryRuleIfStatements"
    // InternalFinalDsl.g:460:1: entryRuleIfStatements returns [EObject current=null] : iv_ruleIfStatements= ruleIfStatements EOF ;
    public final EObject entryRuleIfStatements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfStatements = null;


        try {
            // InternalFinalDsl.g:460:53: (iv_ruleIfStatements= ruleIfStatements EOF )
            // InternalFinalDsl.g:461:2: iv_ruleIfStatements= ruleIfStatements EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getIfStatementsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleIfStatements=ruleIfStatements();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleIfStatements; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfStatements"


    // $ANTLR start "ruleIfStatements"
    // InternalFinalDsl.g:467:1: ruleIfStatements returns [EObject current=null] : (otherlv_0= 'if' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_statements_5_0= ruleStatement ) )+ otherlv_6= '}' ) ;
    public final EObject ruleIfStatements() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_expression_2_0 = null;

        EObject lv_statements_5_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:473:2: ( (otherlv_0= 'if' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_statements_5_0= ruleStatement ) )+ otherlv_6= '}' ) )
            // InternalFinalDsl.g:474:2: (otherlv_0= 'if' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_statements_5_0= ruleStatement ) )+ otherlv_6= '}' )
            {
            // InternalFinalDsl.g:474:2: (otherlv_0= 'if' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_statements_5_0= ruleStatement ) )+ otherlv_6= '}' )
            // InternalFinalDsl.g:475:3: otherlv_0= 'if' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_statements_5_0= ruleStatement ) )+ otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,15,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getIfStatementsAccess().getIfKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getIfStatementsAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalFinalDsl.g:483:3: ( (lv_expression_2_0= ruleExpression ) )
            // InternalFinalDsl.g:484:4: (lv_expression_2_0= ruleExpression )
            {
            // InternalFinalDsl.g:484:4: (lv_expression_2_0= ruleExpression )
            // InternalFinalDsl.g:485:5: lv_expression_2_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getIfStatementsAccess().getExpressionExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_12);
            lv_expression_2_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getIfStatementsRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_2_0,
              						"org.xtext.example.mydsl.FinalDsl.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getIfStatementsAccess().getRightParenthesisKeyword_3());
              		
            }
            otherlv_4=(Token)match(input,16,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getIfStatementsAccess().getLeftCurlyBracketKeyword_4());
              		
            }
            // InternalFinalDsl.g:510:3: ( (lv_statements_5_0= ruleStatement ) )+
            int cnt8=0;
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==13||LA8_0==15||LA8_0==19||LA8_0==23||(LA8_0>=29 && LA8_0<=33)) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalFinalDsl.g:511:4: (lv_statements_5_0= ruleStatement )
            	    {
            	    // InternalFinalDsl.g:511:4: (lv_statements_5_0= ruleStatement )
            	    // InternalFinalDsl.g:512:5: lv_statements_5_0= ruleStatement
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getIfStatementsAccess().getStatementsStatementParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_14);
            	    lv_statements_5_0=ruleStatement();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getIfStatementsRule());
            	      					}
            	      					add(
            	      						current,
            	      						"statements",
            	      						lv_statements_5_0,
            	      						"org.xtext.example.mydsl.FinalDsl.Statement");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt8 >= 1 ) break loop8;
            	    if (state.backtracking>0) {state.failed=true; return current;}
                        EarlyExitException eee =
                            new EarlyExitException(8, input);
                        throw eee;
                }
                cnt8++;
            } while (true);

            otherlv_6=(Token)match(input,17,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_6, grammarAccess.getIfStatementsAccess().getRightCurlyBracketKeyword_6());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfStatements"


    // $ANTLR start "entryRuleElseStatement"
    // InternalFinalDsl.g:537:1: entryRuleElseStatement returns [EObject current=null] : iv_ruleElseStatement= ruleElseStatement EOF ;
    public final EObject entryRuleElseStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElseStatement = null;


        try {
            // InternalFinalDsl.g:537:54: (iv_ruleElseStatement= ruleElseStatement EOF )
            // InternalFinalDsl.g:538:2: iv_ruleElseStatement= ruleElseStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getElseStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleElseStatement=ruleElseStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleElseStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElseStatement"


    // $ANTLR start "ruleElseStatement"
    // InternalFinalDsl.g:544:1: ruleElseStatement returns [EObject current=null] : ( ( ( 'else' )=>otherlv_0= 'else' ) otherlv_1= '{' ( (lv_elseStatement_2_0= ruleStatement ) ) otherlv_3= '}' ) ;
    public final EObject ruleElseStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_elseStatement_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:550:2: ( ( ( ( 'else' )=>otherlv_0= 'else' ) otherlv_1= '{' ( (lv_elseStatement_2_0= ruleStatement ) ) otherlv_3= '}' ) )
            // InternalFinalDsl.g:551:2: ( ( ( 'else' )=>otherlv_0= 'else' ) otherlv_1= '{' ( (lv_elseStatement_2_0= ruleStatement ) ) otherlv_3= '}' )
            {
            // InternalFinalDsl.g:551:2: ( ( ( 'else' )=>otherlv_0= 'else' ) otherlv_1= '{' ( (lv_elseStatement_2_0= ruleStatement ) ) otherlv_3= '}' )
            // InternalFinalDsl.g:552:3: ( ( 'else' )=>otherlv_0= 'else' ) otherlv_1= '{' ( (lv_elseStatement_2_0= ruleStatement ) ) otherlv_3= '}'
            {
            // InternalFinalDsl.g:552:3: ( ( 'else' )=>otherlv_0= 'else' )
            // InternalFinalDsl.g:553:4: ( 'else' )=>otherlv_0= 'else'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_0, grammarAccess.getElseStatementAccess().getElseKeyword_0());
              			
            }

            }

            otherlv_1=(Token)match(input,16,FOLLOW_6); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getElseStatementAccess().getLeftCurlyBracketKeyword_1());
              		
            }
            // InternalFinalDsl.g:563:3: ( (lv_elseStatement_2_0= ruleStatement ) )
            // InternalFinalDsl.g:564:4: (lv_elseStatement_2_0= ruleStatement )
            {
            // InternalFinalDsl.g:564:4: (lv_elseStatement_2_0= ruleStatement )
            // InternalFinalDsl.g:565:5: lv_elseStatement_2_0= ruleStatement
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getElseStatementAccess().getElseStatementStatementParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_15);
            lv_elseStatement_2_0=ruleStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getElseStatementRule());
              					}
              					add(
              						current,
              						"elseStatement",
              						lv_elseStatement_2_0,
              						"org.xtext.example.mydsl.FinalDsl.Statement");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,17,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getElseStatementAccess().getRightCurlyBracketKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElseStatement"


    // $ANTLR start "entryRuleForLoops"
    // InternalFinalDsl.g:590:1: entryRuleForLoops returns [EObject current=null] : iv_ruleForLoops= ruleForLoops EOF ;
    public final EObject entryRuleForLoops() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleForLoops = null;


        try {
            // InternalFinalDsl.g:590:49: (iv_ruleForLoops= ruleForLoops EOF )
            // InternalFinalDsl.g:591:2: iv_ruleForLoops= ruleForLoops EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getForLoopsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleForLoops=ruleForLoops();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleForLoops; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleForLoops"


    // $ANTLR start "ruleForLoops"
    // InternalFinalDsl.g:597:1: ruleForLoops returns [EObject current=null] : (otherlv_0= 'for' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_forStatement_5_0= ruleStatement ) )* otherlv_6= '}' ) ;
    public final EObject ruleForLoops() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_expression_2_0 = null;

        EObject lv_forStatement_5_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:603:2: ( (otherlv_0= 'for' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_forStatement_5_0= ruleStatement ) )* otherlv_6= '}' ) )
            // InternalFinalDsl.g:604:2: (otherlv_0= 'for' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_forStatement_5_0= ruleStatement ) )* otherlv_6= '}' )
            {
            // InternalFinalDsl.g:604:2: (otherlv_0= 'for' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_forStatement_5_0= ruleStatement ) )* otherlv_6= '}' )
            // InternalFinalDsl.g:605:3: otherlv_0= 'for' otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' otherlv_4= '{' ( (lv_forStatement_5_0= ruleStatement ) )* otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,19,FOLLOW_10); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getForLoopsAccess().getForKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,13,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getForLoopsAccess().getLeftParenthesisKeyword_1());
              		
            }
            // InternalFinalDsl.g:613:3: ( (lv_expression_2_0= ruleExpression ) )
            // InternalFinalDsl.g:614:4: (lv_expression_2_0= ruleExpression )
            {
            // InternalFinalDsl.g:614:4: (lv_expression_2_0= ruleExpression )
            // InternalFinalDsl.g:615:5: lv_expression_2_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getForLoopsAccess().getExpressionExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_12);
            lv_expression_2_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getForLoopsRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_2_0,
              						"org.xtext.example.mydsl.FinalDsl.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_13); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getForLoopsAccess().getRightParenthesisKeyword_3());
              		
            }
            otherlv_4=(Token)match(input,16,FOLLOW_14); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_4, grammarAccess.getForLoopsAccess().getLeftCurlyBracketKeyword_4());
              		
            }
            // InternalFinalDsl.g:640:3: ( (lv_forStatement_5_0= ruleStatement ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==13||LA9_0==15||LA9_0==19||LA9_0==23||(LA9_0>=29 && LA9_0<=33)) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalFinalDsl.g:641:4: (lv_forStatement_5_0= ruleStatement )
            	    {
            	    // InternalFinalDsl.g:641:4: (lv_forStatement_5_0= ruleStatement )
            	    // InternalFinalDsl.g:642:5: lv_forStatement_5_0= ruleStatement
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getForLoopsAccess().getForStatementStatementParserRuleCall_5_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_14);
            	    lv_forStatement_5_0=ruleStatement();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getForLoopsRule());
            	      					}
            	      					add(
            	      						current,
            	      						"forStatement",
            	      						lv_forStatement_5_0,
            	      						"org.xtext.example.mydsl.FinalDsl.Statement");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            otherlv_6=(Token)match(input,17,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_6, grammarAccess.getForLoopsAccess().getRightCurlyBracketKeyword_6());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleForLoops"


    // $ANTLR start "entryRuleClassOperationStatement"
    // InternalFinalDsl.g:667:1: entryRuleClassOperationStatement returns [EObject current=null] : iv_ruleClassOperationStatement= ruleClassOperationStatement EOF ;
    public final EObject entryRuleClassOperationStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClassOperationStatement = null;


        try {
            // InternalFinalDsl.g:667:64: (iv_ruleClassOperationStatement= ruleClassOperationStatement EOF )
            // InternalFinalDsl.g:668:2: iv_ruleClassOperationStatement= ruleClassOperationStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClassOperationStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleClassOperationStatement=ruleClassOperationStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleClassOperationStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClassOperationStatement"


    // $ANTLR start "ruleClassOperationStatement"
    // InternalFinalDsl.g:674:1: ruleClassOperationStatement returns [EObject current=null] : ( ( (lv_classOperationName_0_0= ruleClassOperationName ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) ) ;
    public final EObject ruleClassOperationStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_classOperationName_0_0 = null;

        EObject lv_parameterValuationSequence_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:680:2: ( ( ( (lv_classOperationName_0_0= ruleClassOperationName ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) ) )
            // InternalFinalDsl.g:681:2: ( ( (lv_classOperationName_0_0= ruleClassOperationName ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) )
            {
            // InternalFinalDsl.g:681:2: ( ( (lv_classOperationName_0_0= ruleClassOperationName ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) )
            // InternalFinalDsl.g:682:3: ( (lv_classOperationName_0_0= ruleClassOperationName ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' )
            {
            // InternalFinalDsl.g:682:3: ( (lv_classOperationName_0_0= ruleClassOperationName ) )
            // InternalFinalDsl.g:683:4: (lv_classOperationName_0_0= ruleClassOperationName )
            {
            // InternalFinalDsl.g:683:4: (lv_classOperationName_0_0= ruleClassOperationName )
            // InternalFinalDsl.g:684:5: lv_classOperationName_0_0= ruleClassOperationName
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getClassOperationStatementAccess().getClassOperationNameClassOperationNameParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_10);
            lv_classOperationName_0_0=ruleClassOperationName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getClassOperationStatementRule());
              					}
              					add(
              						current,
              						"classOperationName",
              						lv_classOperationName_0_0,
              						"org.xtext.example.mydsl.FinalDsl.ClassOperationName");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:701:3: (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' )
            // InternalFinalDsl.g:702:4: otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')'
            {
            otherlv_1=(Token)match(input,13,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_1, grammarAccess.getClassOperationStatementAccess().getLeftParenthesisKeyword_1_0());
              			
            }
            // InternalFinalDsl.g:706:4: ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==20) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalFinalDsl.g:707:5: (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence )
            	    {
            	    // InternalFinalDsl.g:707:5: (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence )
            	    // InternalFinalDsl.g:708:6: lv_parameterValuationSequence_2_0= ruleParameterValuationSequence
            	    {
            	    if ( state.backtracking==0 ) {

            	      						newCompositeNode(grammarAccess.getClassOperationStatementAccess().getParameterValuationSequenceParameterValuationSequenceParserRuleCall_1_1_0());
            	      					
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_parameterValuationSequence_2_0=ruleParameterValuationSequence();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElementForParent(grammarAccess.getClassOperationStatementRule());
            	      						}
            	      						add(
            	      							current,
            	      							"parameterValuationSequence",
            	      							lv_parameterValuationSequence_2_0,
            	      							"org.xtext.example.mydsl.FinalDsl.ParameterValuationSequence");
            	      						afterParserOrEnumRuleCall();
            	      					
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_3, grammarAccess.getClassOperationStatementAccess().getRightParenthesisKeyword_1_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClassOperationStatement"


    // $ANTLR start "entryRuleLibraryInterFaceMethodStatement"
    // InternalFinalDsl.g:734:1: entryRuleLibraryInterFaceMethodStatement returns [EObject current=null] : iv_ruleLibraryInterFaceMethodStatement= ruleLibraryInterFaceMethodStatement EOF ;
    public final EObject entryRuleLibraryInterFaceMethodStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibraryInterFaceMethodStatement = null;


        try {
            // InternalFinalDsl.g:734:72: (iv_ruleLibraryInterFaceMethodStatement= ruleLibraryInterFaceMethodStatement EOF )
            // InternalFinalDsl.g:735:2: iv_ruleLibraryInterFaceMethodStatement= ruleLibraryInterFaceMethodStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryInterFaceMethodStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibraryInterFaceMethodStatement=ruleLibraryInterFaceMethodStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibraryInterFaceMethodStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibraryInterFaceMethodStatement"


    // $ANTLR start "ruleLibraryInterFaceMethodStatement"
    // InternalFinalDsl.g:741:1: ruleLibraryInterFaceMethodStatement returns [EObject current=null] : ( ( (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) ) ;
    public final EObject ruleLibraryInterFaceMethodStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Enumerator lv_interfaceMethods_0_0 = null;

        EObject lv_parameterValuationSequence_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:747:2: ( ( ( (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) ) )
            // InternalFinalDsl.g:748:2: ( ( (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) )
            {
            // InternalFinalDsl.g:748:2: ( ( (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' ) )
            // InternalFinalDsl.g:749:3: ( (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum ) ) (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' )
            {
            // InternalFinalDsl.g:749:3: ( (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum ) )
            // InternalFinalDsl.g:750:4: (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum )
            {
            // InternalFinalDsl.g:750:4: (lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum )
            // InternalFinalDsl.g:751:5: lv_interfaceMethods_0_0= rulelibraryInterFaceMethodStatementEnum
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getLibraryInterFaceMethodStatementAccess().getInterfaceMethodsLibraryInterFaceMethodStatementEnumEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_10);
            lv_interfaceMethods_0_0=rulelibraryInterFaceMethodStatementEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getLibraryInterFaceMethodStatementRule());
              					}
              					add(
              						current,
              						"interfaceMethods",
              						lv_interfaceMethods_0_0,
              						"org.xtext.example.mydsl.FinalDsl.libraryInterFaceMethodStatementEnum");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:768:3: (otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')' )
            // InternalFinalDsl.g:769:4: otherlv_1= '(' ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )* otherlv_3= ')'
            {
            otherlv_1=(Token)match(input,13,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_1, grammarAccess.getLibraryInterFaceMethodStatementAccess().getLeftParenthesisKeyword_1_0());
              			
            }
            // InternalFinalDsl.g:773:4: ( (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==20) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalFinalDsl.g:774:5: (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence )
            	    {
            	    // InternalFinalDsl.g:774:5: (lv_parameterValuationSequence_2_0= ruleParameterValuationSequence )
            	    // InternalFinalDsl.g:775:6: lv_parameterValuationSequence_2_0= ruleParameterValuationSequence
            	    {
            	    if ( state.backtracking==0 ) {

            	      						newCompositeNode(grammarAccess.getLibraryInterFaceMethodStatementAccess().getParameterValuationSequenceParameterValuationSequenceParserRuleCall_1_1_0());
            	      					
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_parameterValuationSequence_2_0=ruleParameterValuationSequence();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      						if (current==null) {
            	      							current = createModelElementForParent(grammarAccess.getLibraryInterFaceMethodStatementRule());
            	      						}
            	      						add(
            	      							current,
            	      							"parameterValuationSequence",
            	      							lv_parameterValuationSequence_2_0,
            	      							"org.xtext.example.mydsl.FinalDsl.ParameterValuationSequence");
            	      						afterParserOrEnumRuleCall();
            	      					
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

            otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				newLeafNode(otherlv_3, grammarAccess.getLibraryInterFaceMethodStatementAccess().getRightParenthesisKeyword_1_2());
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibraryInterFaceMethodStatement"


    // $ANTLR start "entryRuleLibraryPersistenceMethodStatement"
    // InternalFinalDsl.g:801:1: entryRuleLibraryPersistenceMethodStatement returns [EObject current=null] : iv_ruleLibraryPersistenceMethodStatement= ruleLibraryPersistenceMethodStatement EOF ;
    public final EObject entryRuleLibraryPersistenceMethodStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibraryPersistenceMethodStatement = null;


        try {
            // InternalFinalDsl.g:801:74: (iv_ruleLibraryPersistenceMethodStatement= ruleLibraryPersistenceMethodStatement EOF )
            // InternalFinalDsl.g:802:2: iv_ruleLibraryPersistenceMethodStatement= ruleLibraryPersistenceMethodStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryPersistenceMethodStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibraryPersistenceMethodStatement=ruleLibraryPersistenceMethodStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibraryPersistenceMethodStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibraryPersistenceMethodStatement"


    // $ANTLR start "ruleLibraryPersistenceMethodStatement"
    // InternalFinalDsl.g:808:1: ruleLibraryPersistenceMethodStatement returns [EObject current=null] : ( ( (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' ) ;
    public final EObject ruleLibraryPersistenceMethodStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Enumerator lv_persistenceMethods_0_0 = null;

        EObject lv_additionalPerMethods_2_0 = null;

        EObject lv_additionalBusMethods_3_0 = null;

        EObject lv_parameterValuationSequence_6_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:814:2: ( ( ( (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' ) )
            // InternalFinalDsl.g:815:2: ( ( (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' )
            {
            // InternalFinalDsl.g:815:2: ( ( (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' )
            // InternalFinalDsl.g:816:3: ( (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')'
            {
            // InternalFinalDsl.g:816:3: ( (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum ) )
            // InternalFinalDsl.g:817:4: (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum )
            {
            // InternalFinalDsl.g:817:4: (lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum )
            // InternalFinalDsl.g:818:5: lv_persistenceMethods_0_0= rulelibraryPersistenceMethodStatementEnum
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getLibraryPersistenceMethodStatementAccess().getPersistenceMethodsLibraryPersistenceMethodStatementEnumEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_17);
            lv_persistenceMethods_0_0=rulelibraryPersistenceMethodStatementEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getLibraryPersistenceMethodStatementRule());
              					}
              					add(
              						current,
              						"persistenceMethods",
              						lv_persistenceMethods_0_0,
              						"org.xtext.example.mydsl.FinalDsl.libraryPersistenceMethodStatementEnum");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:835:3: ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )?
            int alt12=3;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==13) ) {
                int LA12_1 = input.LA(2);

                if ( ((LA12_1>=29 && LA12_1<=30)) ) {
                    alt12=1;
                }
            }
            else if ( (LA12_0==31) ) {
                alt12=2;
            }
            switch (alt12) {
                case 1 :
                    // InternalFinalDsl.g:836:4: (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) )
                    {
                    // InternalFinalDsl.g:836:4: (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) )
                    // InternalFinalDsl.g:837:5: otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) )
                    {
                    otherlv_1=(Token)match(input,13,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_1, grammarAccess.getLibraryPersistenceMethodStatementAccess().getLeftParenthesisKeyword_1_0_0());
                      				
                    }
                    // InternalFinalDsl.g:841:5: ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) )
                    // InternalFinalDsl.g:842:6: (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement )
                    {
                    // InternalFinalDsl.g:842:6: (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement )
                    // InternalFinalDsl.g:843:7: lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getLibraryPersistenceMethodStatementAccess().getAdditionalPerMethodsLibraryPersistenceMethodStatementParserRuleCall_1_0_1_0());
                      						
                    }
                    pushFollow(FOLLOW_10);
                    lv_additionalPerMethods_2_0=ruleLibraryPersistenceMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getLibraryPersistenceMethodStatementRule());
                      							}
                      							set(
                      								current,
                      								"additionalPerMethods",
                      								lv_additionalPerMethods_2_0,
                      								"org.xtext.example.mydsl.FinalDsl.LibraryPersistenceMethodStatement");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:862:4: ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' )
                    {
                    // InternalFinalDsl.g:862:4: ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' )
                    // InternalFinalDsl.g:863:5: ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')'
                    {
                    // InternalFinalDsl.g:863:5: ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) )
                    // InternalFinalDsl.g:864:6: (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement )
                    {
                    // InternalFinalDsl.g:864:6: (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement )
                    // InternalFinalDsl.g:865:7: lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getLibraryPersistenceMethodStatementAccess().getAdditionalBusMethodsLibraryBusinessMethodStatementParserRuleCall_1_1_0_0());
                      						
                    }
                    pushFollow(FOLLOW_12);
                    lv_additionalBusMethods_3_0=ruleLibraryBusinessMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getLibraryPersistenceMethodStatementRule());
                      							}
                      							set(
                      								current,
                      								"additionalBusMethods",
                      								lv_additionalBusMethods_3_0,
                      								"org.xtext.example.mydsl.FinalDsl.LibraryBusinessMethodStatement");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }

                    otherlv_4=(Token)match(input,14,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_4, grammarAccess.getLibraryPersistenceMethodStatementAccess().getRightParenthesisKeyword_1_1_1());
                      				
                    }

                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,13,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_5, grammarAccess.getLibraryPersistenceMethodStatementAccess().getLeftParenthesisKeyword_2());
              		
            }
            // InternalFinalDsl.g:892:3: ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==20) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalFinalDsl.g:893:4: (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence )
            	    {
            	    // InternalFinalDsl.g:893:4: (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence )
            	    // InternalFinalDsl.g:894:5: lv_parameterValuationSequence_6_0= ruleParameterValuationSequence
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getLibraryPersistenceMethodStatementAccess().getParameterValuationSequenceParameterValuationSequenceParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_parameterValuationSequence_6_0=ruleParameterValuationSequence();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getLibraryPersistenceMethodStatementRule());
            	      					}
            	      					add(
            	      						current,
            	      						"parameterValuationSequence",
            	      						lv_parameterValuationSequence_6_0,
            	      						"org.xtext.example.mydsl.FinalDsl.ParameterValuationSequence");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            otherlv_7=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_7, grammarAccess.getLibraryPersistenceMethodStatementAccess().getRightParenthesisKeyword_4());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibraryPersistenceMethodStatement"


    // $ANTLR start "entryRuleLibraryBusinessMethodStatement"
    // InternalFinalDsl.g:919:1: entryRuleLibraryBusinessMethodStatement returns [EObject current=null] : iv_ruleLibraryBusinessMethodStatement= ruleLibraryBusinessMethodStatement EOF ;
    public final EObject entryRuleLibraryBusinessMethodStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLibraryBusinessMethodStatement = null;


        try {
            // InternalFinalDsl.g:919:71: (iv_ruleLibraryBusinessMethodStatement= ruleLibraryBusinessMethodStatement EOF )
            // InternalFinalDsl.g:920:2: iv_ruleLibraryBusinessMethodStatement= ruleLibraryBusinessMethodStatement EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getLibraryBusinessMethodStatementRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleLibraryBusinessMethodStatement=ruleLibraryBusinessMethodStatement();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleLibraryBusinessMethodStatement; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLibraryBusinessMethodStatement"


    // $ANTLR start "ruleLibraryBusinessMethodStatement"
    // InternalFinalDsl.g:926:1: ruleLibraryBusinessMethodStatement returns [EObject current=null] : ( ( (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' ) ;
    public final EObject ruleLibraryBusinessMethodStatement() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Enumerator lv_businessMethods_0_0 = null;

        EObject lv_additionalPerMethods_2_0 = null;

        EObject lv_additionalBusMethods_3_0 = null;

        EObject lv_parameterValuationSequence_6_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:932:2: ( ( ( (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' ) )
            // InternalFinalDsl.g:933:2: ( ( (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' )
            {
            // InternalFinalDsl.g:933:2: ( ( (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')' )
            // InternalFinalDsl.g:934:3: ( (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum ) ) ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )? otherlv_5= '(' ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )* otherlv_7= ')'
            {
            // InternalFinalDsl.g:934:3: ( (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum ) )
            // InternalFinalDsl.g:935:4: (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum )
            {
            // InternalFinalDsl.g:935:4: (lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum )
            // InternalFinalDsl.g:936:5: lv_businessMethods_0_0= rulelibraryBusinessMethodStatementEnum
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getLibraryBusinessMethodStatementAccess().getBusinessMethodsLibraryBusinessMethodStatementEnumEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_17);
            lv_businessMethods_0_0=rulelibraryBusinessMethodStatementEnum();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getLibraryBusinessMethodStatementRule());
              					}
              					add(
              						current,
              						"businessMethods",
              						lv_businessMethods_0_0,
              						"org.xtext.example.mydsl.FinalDsl.libraryBusinessMethodStatementEnum");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:953:3: ( (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) ) | ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' ) )?
            int alt14=3;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==13) ) {
                int LA14_1 = input.LA(2);

                if ( ((LA14_1>=29 && LA14_1<=30)) ) {
                    alt14=1;
                }
            }
            else if ( (LA14_0==31) ) {
                alt14=2;
            }
            switch (alt14) {
                case 1 :
                    // InternalFinalDsl.g:954:4: (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) )
                    {
                    // InternalFinalDsl.g:954:4: (otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) ) )
                    // InternalFinalDsl.g:955:5: otherlv_1= '(' ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) )
                    {
                    otherlv_1=(Token)match(input,13,FOLLOW_18); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_1, grammarAccess.getLibraryBusinessMethodStatementAccess().getLeftParenthesisKeyword_1_0_0());
                      				
                    }
                    // InternalFinalDsl.g:959:5: ( (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement ) )
                    // InternalFinalDsl.g:960:6: (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement )
                    {
                    // InternalFinalDsl.g:960:6: (lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement )
                    // InternalFinalDsl.g:961:7: lv_additionalPerMethods_2_0= ruleLibraryPersistenceMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getLibraryBusinessMethodStatementAccess().getAdditionalPerMethodsLibraryPersistenceMethodStatementParserRuleCall_1_0_1_0());
                      						
                    }
                    pushFollow(FOLLOW_10);
                    lv_additionalPerMethods_2_0=ruleLibraryPersistenceMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getLibraryBusinessMethodStatementRule());
                      							}
                      							set(
                      								current,
                      								"additionalPerMethods",
                      								lv_additionalPerMethods_2_0,
                      								"org.xtext.example.mydsl.FinalDsl.LibraryPersistenceMethodStatement");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:980:4: ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' )
                    {
                    // InternalFinalDsl.g:980:4: ( ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')' )
                    // InternalFinalDsl.g:981:5: ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) ) otherlv_4= ')'
                    {
                    // InternalFinalDsl.g:981:5: ( (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement ) )
                    // InternalFinalDsl.g:982:6: (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement )
                    {
                    // InternalFinalDsl.g:982:6: (lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement )
                    // InternalFinalDsl.g:983:7: lv_additionalBusMethods_3_0= ruleLibraryBusinessMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getLibraryBusinessMethodStatementAccess().getAdditionalBusMethodsLibraryBusinessMethodStatementParserRuleCall_1_1_0_0());
                      						
                    }
                    pushFollow(FOLLOW_12);
                    lv_additionalBusMethods_3_0=ruleLibraryBusinessMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getLibraryBusinessMethodStatementRule());
                      							}
                      							set(
                      								current,
                      								"additionalBusMethods",
                      								lv_additionalBusMethods_3_0,
                      								"org.xtext.example.mydsl.FinalDsl.LibraryBusinessMethodStatement");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }

                    otherlv_4=(Token)match(input,14,FOLLOW_10); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_4, grammarAccess.getLibraryBusinessMethodStatementAccess().getRightParenthesisKeyword_1_1_1());
                      				
                    }

                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,13,FOLLOW_16); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_5, grammarAccess.getLibraryBusinessMethodStatementAccess().getLeftParenthesisKeyword_2());
              		
            }
            // InternalFinalDsl.g:1010:3: ( (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==20) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalFinalDsl.g:1011:4: (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence )
            	    {
            	    // InternalFinalDsl.g:1011:4: (lv_parameterValuationSequence_6_0= ruleParameterValuationSequence )
            	    // InternalFinalDsl.g:1012:5: lv_parameterValuationSequence_6_0= ruleParameterValuationSequence
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getLibraryBusinessMethodStatementAccess().getParameterValuationSequenceParameterValuationSequenceParserRuleCall_3_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_16);
            	    lv_parameterValuationSequence_6_0=ruleParameterValuationSequence();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getLibraryBusinessMethodStatementRule());
            	      					}
            	      					add(
            	      						current,
            	      						"parameterValuationSequence",
            	      						lv_parameterValuationSequence_6_0,
            	      						"org.xtext.example.mydsl.FinalDsl.ParameterValuationSequence");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            otherlv_7=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_7, grammarAccess.getLibraryBusinessMethodStatementAccess().getRightParenthesisKeyword_4());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLibraryBusinessMethodStatement"


    // $ANTLR start "entryRuleParameterValuationSequence"
    // InternalFinalDsl.g:1037:1: entryRuleParameterValuationSequence returns [EObject current=null] : iv_ruleParameterValuationSequence= ruleParameterValuationSequence EOF ;
    public final EObject entryRuleParameterValuationSequence() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParameterValuationSequence = null;


        try {
            // InternalFinalDsl.g:1037:67: (iv_ruleParameterValuationSequence= ruleParameterValuationSequence EOF )
            // InternalFinalDsl.g:1038:2: iv_ruleParameterValuationSequence= ruleParameterValuationSequence EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParameterValuationSequenceRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleParameterValuationSequence=ruleParameterValuationSequence();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleParameterValuationSequence; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParameterValuationSequence"


    // $ANTLR start "ruleParameterValuationSequence"
    // InternalFinalDsl.g:1044:1: ruleParameterValuationSequence returns [EObject current=null] : (otherlv_0= 'parameter' ( (lv_parameterName_1_0= ruleExpression ) ) ( (lv_parameterValuation_2_0= ruleParameterValuation ) )* ) ;
    public final EObject ruleParameterValuationSequence() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_parameterName_1_0 = null;

        EObject lv_parameterValuation_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1050:2: ( (otherlv_0= 'parameter' ( (lv_parameterName_1_0= ruleExpression ) ) ( (lv_parameterValuation_2_0= ruleParameterValuation ) )* ) )
            // InternalFinalDsl.g:1051:2: (otherlv_0= 'parameter' ( (lv_parameterName_1_0= ruleExpression ) ) ( (lv_parameterValuation_2_0= ruleParameterValuation ) )* )
            {
            // InternalFinalDsl.g:1051:2: (otherlv_0= 'parameter' ( (lv_parameterName_1_0= ruleExpression ) ) ( (lv_parameterValuation_2_0= ruleParameterValuation ) )* )
            // InternalFinalDsl.g:1052:3: otherlv_0= 'parameter' ( (lv_parameterName_1_0= ruleExpression ) ) ( (lv_parameterValuation_2_0= ruleParameterValuation ) )*
            {
            otherlv_0=(Token)match(input,20,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParameterValuationSequenceAccess().getParameterKeyword_0());
              		
            }
            // InternalFinalDsl.g:1056:3: ( (lv_parameterName_1_0= ruleExpression ) )
            // InternalFinalDsl.g:1057:4: (lv_parameterName_1_0= ruleExpression )
            {
            // InternalFinalDsl.g:1057:4: (lv_parameterName_1_0= ruleExpression )
            // InternalFinalDsl.g:1058:5: lv_parameterName_1_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParameterValuationSequenceAccess().getParameterNameExpressionParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_19);
            lv_parameterName_1_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParameterValuationSequenceRule());
              					}
              					set(
              						current,
              						"parameterName",
              						lv_parameterName_1_0,
              						"org.xtext.example.mydsl.FinalDsl.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1075:3: ( (lv_parameterValuation_2_0= ruleParameterValuation ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==21) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalFinalDsl.g:1076:4: (lv_parameterValuation_2_0= ruleParameterValuation )
            	    {
            	    // InternalFinalDsl.g:1076:4: (lv_parameterValuation_2_0= ruleParameterValuation )
            	    // InternalFinalDsl.g:1077:5: lv_parameterValuation_2_0= ruleParameterValuation
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getParameterValuationSequenceAccess().getParameterValuationParameterValuationParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_19);
            	    lv_parameterValuation_2_0=ruleParameterValuation();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getParameterValuationSequenceRule());
            	      					}
            	      					add(
            	      						current,
            	      						"parameterValuation",
            	      						lv_parameterValuation_2_0,
            	      						"org.xtext.example.mydsl.FinalDsl.ParameterValuation");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParameterValuationSequence"


    // $ANTLR start "entryRuleParameterValuation"
    // InternalFinalDsl.g:1098:1: entryRuleParameterValuation returns [EObject current=null] : iv_ruleParameterValuation= ruleParameterValuation EOF ;
    public final EObject entryRuleParameterValuation() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleParameterValuation = null;


        try {
            // InternalFinalDsl.g:1098:59: (iv_ruleParameterValuation= ruleParameterValuation EOF )
            // InternalFinalDsl.g:1099:2: iv_ruleParameterValuation= ruleParameterValuation EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getParameterValuationRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleParameterValuation=ruleParameterValuation();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleParameterValuation; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleParameterValuation"


    // $ANTLR start "ruleParameterValuation"
    // InternalFinalDsl.g:1105:1: ruleParameterValuation returns [EObject current=null] : (otherlv_0= ',' otherlv_1= 'parameter' ( (lv_parameterName_2_0= ruleExpression ) ) ) ;
    public final EObject ruleParameterValuation() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        EObject lv_parameterName_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1111:2: ( (otherlv_0= ',' otherlv_1= 'parameter' ( (lv_parameterName_2_0= ruleExpression ) ) ) )
            // InternalFinalDsl.g:1112:2: (otherlv_0= ',' otherlv_1= 'parameter' ( (lv_parameterName_2_0= ruleExpression ) ) )
            {
            // InternalFinalDsl.g:1112:2: (otherlv_0= ',' otherlv_1= 'parameter' ( (lv_parameterName_2_0= ruleExpression ) ) )
            // InternalFinalDsl.g:1113:3: otherlv_0= ',' otherlv_1= 'parameter' ( (lv_parameterName_2_0= ruleExpression ) )
            {
            otherlv_0=(Token)match(input,21,FOLLOW_20); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getParameterValuationAccess().getCommaKeyword_0());
              		
            }
            otherlv_1=(Token)match(input,20,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_1, grammarAccess.getParameterValuationAccess().getParameterKeyword_1());
              		
            }
            // InternalFinalDsl.g:1121:3: ( (lv_parameterName_2_0= ruleExpression ) )
            // InternalFinalDsl.g:1122:4: (lv_parameterName_2_0= ruleExpression )
            {
            // InternalFinalDsl.g:1122:4: (lv_parameterName_2_0= ruleExpression )
            // InternalFinalDsl.g:1123:5: lv_parameterName_2_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getParameterValuationAccess().getParameterNameExpressionParserRuleCall_2_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_parameterName_2_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getParameterValuationRule());
              					}
              					set(
              						current,
              						"parameterName",
              						lv_parameterName_2_0,
              						"org.xtext.example.mydsl.FinalDsl.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleParameterValuation"


    // $ANTLR start "entryRuleClassAttributeName"
    // InternalFinalDsl.g:1144:1: entryRuleClassAttributeName returns [EObject current=null] : iv_ruleClassAttributeName= ruleClassAttributeName EOF ;
    public final EObject entryRuleClassAttributeName() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClassAttributeName = null;


        try {
            // InternalFinalDsl.g:1144:59: (iv_ruleClassAttributeName= ruleClassAttributeName EOF )
            // InternalFinalDsl.g:1145:2: iv_ruleClassAttributeName= ruleClassAttributeName EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClassAttributeNameRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleClassAttributeName=ruleClassAttributeName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleClassAttributeName; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClassAttributeName"


    // $ANTLR start "ruleClassAttributeName"
    // InternalFinalDsl.g:1151:1: ruleClassAttributeName returns [EObject current=null] : (otherlv_0= 'ClassAttribute' ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject ruleClassAttributeName() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:1157:2: ( (otherlv_0= 'ClassAttribute' ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalFinalDsl.g:1158:2: (otherlv_0= 'ClassAttribute' ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalFinalDsl.g:1158:2: (otherlv_0= 'ClassAttribute' ( (lv_name_1_0= RULE_ID ) ) )
            // InternalFinalDsl.g:1159:3: otherlv_0= 'ClassAttribute' ( (lv_name_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,22,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getClassAttributeNameAccess().getClassAttributeKeyword_0());
              		
            }
            // InternalFinalDsl.g:1163:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalFinalDsl.g:1164:4: (lv_name_1_0= RULE_ID )
            {
            // InternalFinalDsl.g:1164:4: (lv_name_1_0= RULE_ID )
            // InternalFinalDsl.g:1165:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_name_1_0, grammarAccess.getClassAttributeNameAccess().getNameIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getClassAttributeNameRule());
              					}
              					setWithLastConsumed(
              						current,
              						"name",
              						lv_name_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClassAttributeName"


    // $ANTLR start "entryRuleClassOperationName"
    // InternalFinalDsl.g:1185:1: entryRuleClassOperationName returns [EObject current=null] : iv_ruleClassOperationName= ruleClassOperationName EOF ;
    public final EObject entryRuleClassOperationName() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClassOperationName = null;


        try {
            // InternalFinalDsl.g:1185:59: (iv_ruleClassOperationName= ruleClassOperationName EOF )
            // InternalFinalDsl.g:1186:2: iv_ruleClassOperationName= ruleClassOperationName EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getClassOperationNameRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleClassOperationName=ruleClassOperationName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleClassOperationName; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClassOperationName"


    // $ANTLR start "ruleClassOperationName"
    // InternalFinalDsl.g:1192:1: ruleClassOperationName returns [EObject current=null] : (otherlv_0= 'ClassOperation' ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject ruleClassOperationName() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:1198:2: ( (otherlv_0= 'ClassOperation' ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalFinalDsl.g:1199:2: (otherlv_0= 'ClassOperation' ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalFinalDsl.g:1199:2: (otherlv_0= 'ClassOperation' ( (lv_name_1_0= RULE_ID ) ) )
            // InternalFinalDsl.g:1200:3: otherlv_0= 'ClassOperation' ( (lv_name_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,23,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getClassOperationNameAccess().getClassOperationKeyword_0());
              		
            }
            // InternalFinalDsl.g:1204:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalFinalDsl.g:1205:4: (lv_name_1_0= RULE_ID )
            {
            // InternalFinalDsl.g:1205:4: (lv_name_1_0= RULE_ID )
            // InternalFinalDsl.g:1206:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_name_1_0, grammarAccess.getClassOperationNameAccess().getNameIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getClassOperationNameRule());
              					}
              					setWithLastConsumed(
              						current,
              						"name",
              						lv_name_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClassOperationName"


    // $ANTLR start "entryRuleOperationParameterName"
    // InternalFinalDsl.g:1226:1: entryRuleOperationParameterName returns [EObject current=null] : iv_ruleOperationParameterName= ruleOperationParameterName EOF ;
    public final EObject entryRuleOperationParameterName() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOperationParameterName = null;


        try {
            // InternalFinalDsl.g:1226:63: (iv_ruleOperationParameterName= ruleOperationParameterName EOF )
            // InternalFinalDsl.g:1227:2: iv_ruleOperationParameterName= ruleOperationParameterName EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getOperationParameterNameRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleOperationParameterName=ruleOperationParameterName();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleOperationParameterName; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOperationParameterName"


    // $ANTLR start "ruleOperationParameterName"
    // InternalFinalDsl.g:1233:1: ruleOperationParameterName returns [EObject current=null] : (otherlv_0= 'OperationParameter' ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject ruleOperationParameterName() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:1239:2: ( (otherlv_0= 'OperationParameter' ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalFinalDsl.g:1240:2: (otherlv_0= 'OperationParameter' ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalFinalDsl.g:1240:2: (otherlv_0= 'OperationParameter' ( (lv_name_1_0= RULE_ID ) ) )
            // InternalFinalDsl.g:1241:3: otherlv_0= 'OperationParameter' ( (lv_name_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,24,FOLLOW_5); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getOperationParameterNameAccess().getOperationParameterKeyword_0());
              		
            }
            // InternalFinalDsl.g:1245:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalFinalDsl.g:1246:4: (lv_name_1_0= RULE_ID )
            {
            // InternalFinalDsl.g:1246:4: (lv_name_1_0= RULE_ID )
            // InternalFinalDsl.g:1247:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					newLeafNode(lv_name_1_0, grammarAccess.getOperationParameterNameAccess().getNameIDTerminalRuleCall_1_0());
              				
            }
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElement(grammarAccess.getOperationParameterNameRule());
              					}
              					setWithLastConsumed(
              						current,
              						"name",
              						lv_name_1_0,
              						"org.eclipse.xtext.common.Terminals.ID");
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperationParameterName"


    // $ANTLR start "entryRuleExpression"
    // InternalFinalDsl.g:1267:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalFinalDsl.g:1267:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalFinalDsl.g:1268:2: iv_ruleExpression= ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalFinalDsl.g:1274:1: ruleExpression returns [EObject current=null] : ( ( (lv_simpleExpression_0_0= ruleSimpleExpression ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalExpressions ) )* ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_simpleExpression_0_0 = null;

        EObject lv_additionalExpressions_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1280:2: ( ( ( (lv_simpleExpression_0_0= ruleSimpleExpression ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalExpressions ) )* ) )
            // InternalFinalDsl.g:1281:2: ( ( (lv_simpleExpression_0_0= ruleSimpleExpression ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalExpressions ) )* )
            {
            // InternalFinalDsl.g:1281:2: ( ( (lv_simpleExpression_0_0= ruleSimpleExpression ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalExpressions ) )* )
            // InternalFinalDsl.g:1282:3: ( (lv_simpleExpression_0_0= ruleSimpleExpression ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalExpressions ) )*
            {
            // InternalFinalDsl.g:1282:3: ( (lv_simpleExpression_0_0= ruleSimpleExpression ) )
            // InternalFinalDsl.g:1283:4: (lv_simpleExpression_0_0= ruleSimpleExpression )
            {
            // InternalFinalDsl.g:1283:4: (lv_simpleExpression_0_0= ruleSimpleExpression )
            // InternalFinalDsl.g:1284:5: lv_simpleExpression_0_0= ruleSimpleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getExpressionAccess().getSimpleExpressionSimpleExpressionParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_21);
            lv_simpleExpression_0_0=ruleSimpleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getExpressionRule());
              					}
              					set(
              						current,
              						"simpleExpression",
              						lv_simpleExpression_0_0,
              						"org.xtext.example.mydsl.FinalDsl.SimpleExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1301:3: ( (lv_additionalExpressions_1_0= ruleAdditionalExpressions ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>=34 && LA17_0<=40)) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalFinalDsl.g:1302:4: (lv_additionalExpressions_1_0= ruleAdditionalExpressions )
            	    {
            	    // InternalFinalDsl.g:1302:4: (lv_additionalExpressions_1_0= ruleAdditionalExpressions )
            	    // InternalFinalDsl.g:1303:5: lv_additionalExpressions_1_0= ruleAdditionalExpressions
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getExpressionAccess().getAdditionalExpressionsAdditionalExpressionsParserRuleCall_1_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_21);
            	    lv_additionalExpressions_1_0=ruleAdditionalExpressions();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getExpressionRule());
            	      					}
            	      					add(
            	      						current,
            	      						"additionalExpressions",
            	      						lv_additionalExpressions_1_0,
            	      						"org.xtext.example.mydsl.FinalDsl.AdditionalExpressions");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleSimpleExpression"
    // InternalFinalDsl.g:1324:1: entryRuleSimpleExpression returns [EObject current=null] : iv_ruleSimpleExpression= ruleSimpleExpression EOF ;
    public final EObject entryRuleSimpleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSimpleExpression = null;


        try {
            // InternalFinalDsl.g:1324:57: (iv_ruleSimpleExpression= ruleSimpleExpression EOF )
            // InternalFinalDsl.g:1325:2: iv_ruleSimpleExpression= ruleSimpleExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSimpleExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSimpleExpression=ruleSimpleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSimpleExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSimpleExpression"


    // $ANTLR start "ruleSimpleExpression"
    // InternalFinalDsl.g:1331:1: ruleSimpleExpression returns [EObject current=null] : ( ( (lv_term_0_0= ruleTerm ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions ) )* ) ;
    public final EObject ruleSimpleExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_term_0_0 = null;

        EObject lv_additionalExpressions_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1337:2: ( ( ( (lv_term_0_0= ruleTerm ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions ) )* ) )
            // InternalFinalDsl.g:1338:2: ( ( (lv_term_0_0= ruleTerm ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions ) )* )
            {
            // InternalFinalDsl.g:1338:2: ( ( (lv_term_0_0= ruleTerm ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions ) )* )
            // InternalFinalDsl.g:1339:3: ( (lv_term_0_0= ruleTerm ) ) ( (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions ) )*
            {
            // InternalFinalDsl.g:1339:3: ( (lv_term_0_0= ruleTerm ) )
            // InternalFinalDsl.g:1340:4: (lv_term_0_0= ruleTerm )
            {
            // InternalFinalDsl.g:1340:4: (lv_term_0_0= ruleTerm )
            // InternalFinalDsl.g:1341:5: lv_term_0_0= ruleTerm
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getSimpleExpressionAccess().getTermTermParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_22);
            lv_term_0_0=ruleTerm();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getSimpleExpressionRule());
              					}
              					set(
              						current,
              						"term",
              						lv_term_0_0,
              						"org.xtext.example.mydsl.FinalDsl.Term");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1358:3: ( (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions ) )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>=41 && LA18_0<=43)) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalFinalDsl.g:1359:4: (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions )
            	    {
            	    // InternalFinalDsl.g:1359:4: (lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions )
            	    // InternalFinalDsl.g:1360:5: lv_additionalExpressions_1_0= ruleAdditionalSimpleExpressions
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getSimpleExpressionAccess().getAdditionalExpressionsAdditionalSimpleExpressionsParserRuleCall_1_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_22);
            	    lv_additionalExpressions_1_0=ruleAdditionalSimpleExpressions();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getSimpleExpressionRule());
            	      					}
            	      					add(
            	      						current,
            	      						"additionalExpressions",
            	      						lv_additionalExpressions_1_0,
            	      						"org.xtext.example.mydsl.FinalDsl.AdditionalSimpleExpressions");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSimpleExpression"


    // $ANTLR start "entryRuleAdditionalExpressions"
    // InternalFinalDsl.g:1381:1: entryRuleAdditionalExpressions returns [EObject current=null] : iv_ruleAdditionalExpressions= ruleAdditionalExpressions EOF ;
    public final EObject entryRuleAdditionalExpressions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdditionalExpressions = null;


        try {
            // InternalFinalDsl.g:1381:62: (iv_ruleAdditionalExpressions= ruleAdditionalExpressions EOF )
            // InternalFinalDsl.g:1382:2: iv_ruleAdditionalExpressions= ruleAdditionalExpressions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAdditionalExpressionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAdditionalExpressions=ruleAdditionalExpressions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAdditionalExpressions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdditionalExpressions"


    // $ANTLR start "ruleAdditionalExpressions"
    // InternalFinalDsl.g:1388:1: ruleAdditionalExpressions returns [EObject current=null] : ( ( (lv_operator_0_0= ruleRelationalOperator ) ) ( (lv_simpleExpression_1_0= ruleSimpleExpression ) ) ) ;
    public final EObject ruleAdditionalExpressions() throws RecognitionException {
        EObject current = null;

        Enumerator lv_operator_0_0 = null;

        EObject lv_simpleExpression_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1394:2: ( ( ( (lv_operator_0_0= ruleRelationalOperator ) ) ( (lv_simpleExpression_1_0= ruleSimpleExpression ) ) ) )
            // InternalFinalDsl.g:1395:2: ( ( (lv_operator_0_0= ruleRelationalOperator ) ) ( (lv_simpleExpression_1_0= ruleSimpleExpression ) ) )
            {
            // InternalFinalDsl.g:1395:2: ( ( (lv_operator_0_0= ruleRelationalOperator ) ) ( (lv_simpleExpression_1_0= ruleSimpleExpression ) ) )
            // InternalFinalDsl.g:1396:3: ( (lv_operator_0_0= ruleRelationalOperator ) ) ( (lv_simpleExpression_1_0= ruleSimpleExpression ) )
            {
            // InternalFinalDsl.g:1396:3: ( (lv_operator_0_0= ruleRelationalOperator ) )
            // InternalFinalDsl.g:1397:4: (lv_operator_0_0= ruleRelationalOperator )
            {
            // InternalFinalDsl.g:1397:4: (lv_operator_0_0= ruleRelationalOperator )
            // InternalFinalDsl.g:1398:5: lv_operator_0_0= ruleRelationalOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getAdditionalExpressionsAccess().getOperatorRelationalOperatorEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_11);
            lv_operator_0_0=ruleRelationalOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getAdditionalExpressionsRule());
              					}
              					set(
              						current,
              						"operator",
              						lv_operator_0_0,
              						"org.xtext.example.mydsl.FinalDsl.RelationalOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1415:3: ( (lv_simpleExpression_1_0= ruleSimpleExpression ) )
            // InternalFinalDsl.g:1416:4: (lv_simpleExpression_1_0= ruleSimpleExpression )
            {
            // InternalFinalDsl.g:1416:4: (lv_simpleExpression_1_0= ruleSimpleExpression )
            // InternalFinalDsl.g:1417:5: lv_simpleExpression_1_0= ruleSimpleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getAdditionalExpressionsAccess().getSimpleExpressionSimpleExpressionParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_simpleExpression_1_0=ruleSimpleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getAdditionalExpressionsRule());
              					}
              					set(
              						current,
              						"simpleExpression",
              						lv_simpleExpression_1_0,
              						"org.xtext.example.mydsl.FinalDsl.SimpleExpression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionalExpressions"


    // $ANTLR start "entryRuleAdditionalSimpleExpressions"
    // InternalFinalDsl.g:1438:1: entryRuleAdditionalSimpleExpressions returns [EObject current=null] : iv_ruleAdditionalSimpleExpressions= ruleAdditionalSimpleExpressions EOF ;
    public final EObject entryRuleAdditionalSimpleExpressions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdditionalSimpleExpressions = null;


        try {
            // InternalFinalDsl.g:1438:68: (iv_ruleAdditionalSimpleExpressions= ruleAdditionalSimpleExpressions EOF )
            // InternalFinalDsl.g:1439:2: iv_ruleAdditionalSimpleExpressions= ruleAdditionalSimpleExpressions EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAdditionalSimpleExpressionsRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAdditionalSimpleExpressions=ruleAdditionalSimpleExpressions();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAdditionalSimpleExpressions; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdditionalSimpleExpressions"


    // $ANTLR start "ruleAdditionalSimpleExpressions"
    // InternalFinalDsl.g:1445:1: ruleAdditionalSimpleExpressions returns [EObject current=null] : ( ( (lv_additionOperator_0_0= ruleAdditionOperator ) ) ( (lv_term_1_0= ruleTerm ) ) ) ;
    public final EObject ruleAdditionalSimpleExpressions() throws RecognitionException {
        EObject current = null;

        Enumerator lv_additionOperator_0_0 = null;

        EObject lv_term_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1451:2: ( ( ( (lv_additionOperator_0_0= ruleAdditionOperator ) ) ( (lv_term_1_0= ruleTerm ) ) ) )
            // InternalFinalDsl.g:1452:2: ( ( (lv_additionOperator_0_0= ruleAdditionOperator ) ) ( (lv_term_1_0= ruleTerm ) ) )
            {
            // InternalFinalDsl.g:1452:2: ( ( (lv_additionOperator_0_0= ruleAdditionOperator ) ) ( (lv_term_1_0= ruleTerm ) ) )
            // InternalFinalDsl.g:1453:3: ( (lv_additionOperator_0_0= ruleAdditionOperator ) ) ( (lv_term_1_0= ruleTerm ) )
            {
            // InternalFinalDsl.g:1453:3: ( (lv_additionOperator_0_0= ruleAdditionOperator ) )
            // InternalFinalDsl.g:1454:4: (lv_additionOperator_0_0= ruleAdditionOperator )
            {
            // InternalFinalDsl.g:1454:4: (lv_additionOperator_0_0= ruleAdditionOperator )
            // InternalFinalDsl.g:1455:5: lv_additionOperator_0_0= ruleAdditionOperator
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getAdditionalSimpleExpressionsAccess().getAdditionOperatorAdditionOperatorEnumRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_11);
            lv_additionOperator_0_0=ruleAdditionOperator();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getAdditionalSimpleExpressionsRule());
              					}
              					set(
              						current,
              						"additionOperator",
              						lv_additionOperator_0_0,
              						"org.xtext.example.mydsl.FinalDsl.AdditionOperator");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1472:3: ( (lv_term_1_0= ruleTerm ) )
            // InternalFinalDsl.g:1473:4: (lv_term_1_0= ruleTerm )
            {
            // InternalFinalDsl.g:1473:4: (lv_term_1_0= ruleTerm )
            // InternalFinalDsl.g:1474:5: lv_term_1_0= ruleTerm
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getAdditionalSimpleExpressionsAccess().getTermTermParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_term_1_0=ruleTerm();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getAdditionalSimpleExpressionsRule());
              					}
              					set(
              						current,
              						"term",
              						lv_term_1_0,
              						"org.xtext.example.mydsl.FinalDsl.Term");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionalSimpleExpressions"


    // $ANTLR start "entryRuleTerm"
    // InternalFinalDsl.g:1495:1: entryRuleTerm returns [EObject current=null] : iv_ruleTerm= ruleTerm EOF ;
    public final EObject entryRuleTerm() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTerm = null;


        try {
            // InternalFinalDsl.g:1495:45: (iv_ruleTerm= ruleTerm EOF )
            // InternalFinalDsl.g:1496:2: iv_ruleTerm= ruleTerm EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getTermRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleTerm=ruleTerm();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleTerm; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTerm"


    // $ANTLR start "ruleTerm"
    // InternalFinalDsl.g:1502:1: ruleTerm returns [EObject current=null] : ( ( (lv_factorTerm_0_0= ruleFactor ) ) ( (lv_additionalTerm_1_0= ruleAdditionalTerm ) )* ) ;
    public final EObject ruleTerm() throws RecognitionException {
        EObject current = null;

        EObject lv_factorTerm_0_0 = null;

        EObject lv_additionalTerm_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1508:2: ( ( ( (lv_factorTerm_0_0= ruleFactor ) ) ( (lv_additionalTerm_1_0= ruleAdditionalTerm ) )* ) )
            // InternalFinalDsl.g:1509:2: ( ( (lv_factorTerm_0_0= ruleFactor ) ) ( (lv_additionalTerm_1_0= ruleAdditionalTerm ) )* )
            {
            // InternalFinalDsl.g:1509:2: ( ( (lv_factorTerm_0_0= ruleFactor ) ) ( (lv_additionalTerm_1_0= ruleAdditionalTerm ) )* )
            // InternalFinalDsl.g:1510:3: ( (lv_factorTerm_0_0= ruleFactor ) ) ( (lv_additionalTerm_1_0= ruleAdditionalTerm ) )*
            {
            // InternalFinalDsl.g:1510:3: ( (lv_factorTerm_0_0= ruleFactor ) )
            // InternalFinalDsl.g:1511:4: (lv_factorTerm_0_0= ruleFactor )
            {
            // InternalFinalDsl.g:1511:4: (lv_factorTerm_0_0= ruleFactor )
            // InternalFinalDsl.g:1512:5: lv_factorTerm_0_0= ruleFactor
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getTermAccess().getFactorTermFactorParserRuleCall_0_0());
              				
            }
            pushFollow(FOLLOW_23);
            lv_factorTerm_0_0=ruleFactor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getTermRule());
              					}
              					set(
              						current,
              						"factorTerm",
              						lv_factorTerm_0_0,
              						"org.xtext.example.mydsl.FinalDsl.Factor");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1529:3: ( (lv_additionalTerm_1_0= ruleAdditionalTerm ) )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_STRING||LA19_0==RULE_INT||LA19_0==13||LA19_0==22||(LA19_0>=24 && LA19_0<=27)||LA19_0==31||(LA19_0>=44 && LA19_0<=46)) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalFinalDsl.g:1530:4: (lv_additionalTerm_1_0= ruleAdditionalTerm )
            	    {
            	    // InternalFinalDsl.g:1530:4: (lv_additionalTerm_1_0= ruleAdditionalTerm )
            	    // InternalFinalDsl.g:1531:5: lv_additionalTerm_1_0= ruleAdditionalTerm
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getTermAccess().getAdditionalTermAdditionalTermParserRuleCall_1_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_23);
            	    lv_additionalTerm_1_0=ruleAdditionalTerm();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getTermRule());
            	      					}
            	      					add(
            	      						current,
            	      						"additionalTerm",
            	      						lv_additionalTerm_1_0,
            	      						"org.xtext.example.mydsl.FinalDsl.AdditionalTerm");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTerm"


    // $ANTLR start "entryRuleAdditionalTerm"
    // InternalFinalDsl.g:1552:1: entryRuleAdditionalTerm returns [EObject current=null] : iv_ruleAdditionalTerm= ruleAdditionalTerm EOF ;
    public final EObject entryRuleAdditionalTerm() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdditionalTerm = null;


        try {
            // InternalFinalDsl.g:1552:55: (iv_ruleAdditionalTerm= ruleAdditionalTerm EOF )
            // InternalFinalDsl.g:1553:2: iv_ruleAdditionalTerm= ruleAdditionalTerm EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getAdditionalTermRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleAdditionalTerm=ruleAdditionalTerm();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleAdditionalTerm; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdditionalTerm"


    // $ANTLR start "ruleAdditionalTerm"
    // InternalFinalDsl.g:1559:1: ruleAdditionalTerm returns [EObject current=null] : ( ( (lv_multiplicationOperator_0_0= ruleMultiplicationOperator ) )* ( (lv_factor_1_0= ruleFactor ) ) ) ;
    public final EObject ruleAdditionalTerm() throws RecognitionException {
        EObject current = null;

        Enumerator lv_multiplicationOperator_0_0 = null;

        EObject lv_factor_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1565:2: ( ( ( (lv_multiplicationOperator_0_0= ruleMultiplicationOperator ) )* ( (lv_factor_1_0= ruleFactor ) ) ) )
            // InternalFinalDsl.g:1566:2: ( ( (lv_multiplicationOperator_0_0= ruleMultiplicationOperator ) )* ( (lv_factor_1_0= ruleFactor ) ) )
            {
            // InternalFinalDsl.g:1566:2: ( ( (lv_multiplicationOperator_0_0= ruleMultiplicationOperator ) )* ( (lv_factor_1_0= ruleFactor ) ) )
            // InternalFinalDsl.g:1567:3: ( (lv_multiplicationOperator_0_0= ruleMultiplicationOperator ) )* ( (lv_factor_1_0= ruleFactor ) )
            {
            // InternalFinalDsl.g:1567:3: ( (lv_multiplicationOperator_0_0= ruleMultiplicationOperator ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>=44 && LA20_0<=46)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalFinalDsl.g:1568:4: (lv_multiplicationOperator_0_0= ruleMultiplicationOperator )
            	    {
            	    // InternalFinalDsl.g:1568:4: (lv_multiplicationOperator_0_0= ruleMultiplicationOperator )
            	    // InternalFinalDsl.g:1569:5: lv_multiplicationOperator_0_0= ruleMultiplicationOperator
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getAdditionalTermAccess().getMultiplicationOperatorMultiplicationOperatorEnumRuleCall_0_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_24);
            	    lv_multiplicationOperator_0_0=ruleMultiplicationOperator();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getAdditionalTermRule());
            	      					}
            	      					add(
            	      						current,
            	      						"multiplicationOperator",
            	      						lv_multiplicationOperator_0_0,
            	      						"org.xtext.example.mydsl.FinalDsl.MultiplicationOperator");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            // InternalFinalDsl.g:1586:3: ( (lv_factor_1_0= ruleFactor ) )
            // InternalFinalDsl.g:1587:4: (lv_factor_1_0= ruleFactor )
            {
            // InternalFinalDsl.g:1587:4: (lv_factor_1_0= ruleFactor )
            // InternalFinalDsl.g:1588:5: lv_factor_1_0= ruleFactor
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getAdditionalTermAccess().getFactorFactorParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_factor_1_0=ruleFactor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getAdditionalTermRule());
              					}
              					set(
              						current,
              						"factor",
              						lv_factor_1_0,
              						"org.xtext.example.mydsl.FinalDsl.Factor");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionalTerm"


    // $ANTLR start "entryRuleFactor"
    // InternalFinalDsl.g:1609:1: entryRuleFactor returns [EObject current=null] : iv_ruleFactor= ruleFactor EOF ;
    public final EObject entryRuleFactor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFactor = null;


        try {
            // InternalFinalDsl.g:1609:47: (iv_ruleFactor= ruleFactor EOF )
            // InternalFinalDsl.g:1610:2: iv_ruleFactor= ruleFactor EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFactorRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFactor=ruleFactor();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFactor; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFactor"


    // $ANTLR start "ruleFactor"
    // InternalFinalDsl.g:1616:1: ruleFactor returns [EObject current=null] : ( () ( (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) ) | (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) ) | ( (lv_factor_5_0= ruleFactorExpression ) ) | ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) ) ) ) ;
    public final EObject ruleFactor() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject lv_factor_2_0 = null;

        EObject lv_factor_4_0 = null;

        EObject lv_factor_5_0 = null;

        EObject lv_libraryBusinessMethod_6_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1622:2: ( ( () ( (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) ) | (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) ) | ( (lv_factor_5_0= ruleFactorExpression ) ) | ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) ) ) ) )
            // InternalFinalDsl.g:1623:2: ( () ( (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) ) | (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) ) | ( (lv_factor_5_0= ruleFactorExpression ) ) | ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) ) ) )
            {
            // InternalFinalDsl.g:1623:2: ( () ( (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) ) | (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) ) | ( (lv_factor_5_0= ruleFactorExpression ) ) | ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) ) ) )
            // InternalFinalDsl.g:1624:3: () ( (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) ) | (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) ) | ( (lv_factor_5_0= ruleFactorExpression ) ) | ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) ) )
            {
            // InternalFinalDsl.g:1624:3: ()
            // InternalFinalDsl.g:1625:4: 
            {
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getFactorAccess().getFactorAction_0(),
              					current);
              			
            }

            }

            // InternalFinalDsl.g:1631:3: ( (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) ) | (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) ) | ( (lv_factor_5_0= ruleFactorExpression ) ) | ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) ) )
            int alt21=4;
            switch ( input.LA(1) ) {
            case 25:
                {
                alt21=1;
                }
                break;
            case 26:
                {
                alt21=2;
                }
                break;
            case RULE_STRING:
            case RULE_INT:
            case 13:
            case 22:
            case 24:
            case 27:
                {
                alt21=3;
                }
                break;
            case 31:
                {
                alt21=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalFinalDsl.g:1632:4: (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) )
                    {
                    // InternalFinalDsl.g:1632:4: (otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) ) )
                    // InternalFinalDsl.g:1633:5: otherlv_1= 'not' ( (lv_factor_2_0= ruleFactorExpression ) )
                    {
                    otherlv_1=(Token)match(input,25,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_1, grammarAccess.getFactorAccess().getNotKeyword_1_0_0());
                      				
                    }
                    // InternalFinalDsl.g:1637:5: ( (lv_factor_2_0= ruleFactorExpression ) )
                    // InternalFinalDsl.g:1638:6: (lv_factor_2_0= ruleFactorExpression )
                    {
                    // InternalFinalDsl.g:1638:6: (lv_factor_2_0= ruleFactorExpression )
                    // InternalFinalDsl.g:1639:7: lv_factor_2_0= ruleFactorExpression
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getFactorAccess().getFactorFactorExpressionParserRuleCall_1_0_1_0());
                      						
                    }
                    pushFollow(FOLLOW_2);
                    lv_factor_2_0=ruleFactorExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getFactorRule());
                      							}
                      							set(
                      								current,
                      								"factor",
                      								lv_factor_2_0,
                      								"org.xtext.example.mydsl.FinalDsl.FactorExpression");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:1658:4: (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) )
                    {
                    // InternalFinalDsl.g:1658:4: (otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) ) )
                    // InternalFinalDsl.g:1659:5: otherlv_3= 'notIn' ( (lv_factor_4_0= ruleFactorExpression ) )
                    {
                    otherlv_3=(Token)match(input,26,FOLLOW_25); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getFactorAccess().getNotInKeyword_1_1_0());
                      				
                    }
                    // InternalFinalDsl.g:1663:5: ( (lv_factor_4_0= ruleFactorExpression ) )
                    // InternalFinalDsl.g:1664:6: (lv_factor_4_0= ruleFactorExpression )
                    {
                    // InternalFinalDsl.g:1664:6: (lv_factor_4_0= ruleFactorExpression )
                    // InternalFinalDsl.g:1665:7: lv_factor_4_0= ruleFactorExpression
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getFactorAccess().getFactorFactorExpressionParserRuleCall_1_1_1_0());
                      						
                    }
                    pushFollow(FOLLOW_2);
                    lv_factor_4_0=ruleFactorExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getFactorRule());
                      							}
                      							set(
                      								current,
                      								"factor",
                      								lv_factor_4_0,
                      								"org.xtext.example.mydsl.FinalDsl.FactorExpression");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:1684:4: ( (lv_factor_5_0= ruleFactorExpression ) )
                    {
                    // InternalFinalDsl.g:1684:4: ( (lv_factor_5_0= ruleFactorExpression ) )
                    // InternalFinalDsl.g:1685:5: (lv_factor_5_0= ruleFactorExpression )
                    {
                    // InternalFinalDsl.g:1685:5: (lv_factor_5_0= ruleFactorExpression )
                    // InternalFinalDsl.g:1686:6: lv_factor_5_0= ruleFactorExpression
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFactorAccess().getFactorFactorExpressionParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_factor_5_0=ruleFactorExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFactorRule());
                      						}
                      						set(
                      							current,
                      							"factor",
                      							lv_factor_5_0,
                      							"org.xtext.example.mydsl.FinalDsl.FactorExpression");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalFinalDsl.g:1704:4: ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) )
                    {
                    // InternalFinalDsl.g:1704:4: ( (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement ) )
                    // InternalFinalDsl.g:1705:5: (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement )
                    {
                    // InternalFinalDsl.g:1705:5: (lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement )
                    // InternalFinalDsl.g:1706:6: lv_libraryBusinessMethod_6_0= ruleLibraryBusinessMethodStatement
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFactorAccess().getLibraryBusinessMethodLibraryBusinessMethodStatementParserRuleCall_1_3_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_libraryBusinessMethod_6_0=ruleLibraryBusinessMethodStatement();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFactorRule());
                      						}
                      						set(
                      							current,
                      							"libraryBusinessMethod",
                      							lv_libraryBusinessMethod_6_0,
                      							"org.xtext.example.mydsl.FinalDsl.LibraryBusinessMethodStatement");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFactor"


    // $ANTLR start "entryRuleFactorExpression"
    // InternalFinalDsl.g:1728:1: entryRuleFactorExpression returns [EObject current=null] : iv_ruleFactorExpression= ruleFactorExpression EOF ;
    public final EObject entryRuleFactorExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFactorExpression = null;


        try {
            // InternalFinalDsl.g:1728:57: (iv_ruleFactorExpression= ruleFactorExpression EOF )
            // InternalFinalDsl.g:1729:2: iv_ruleFactorExpression= ruleFactorExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getFactorExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleFactorExpression=ruleFactorExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleFactorExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFactorExpression"


    // $ANTLR start "ruleFactorExpression"
    // InternalFinalDsl.g:1735:1: ruleFactorExpression returns [EObject current=null] : ( () ( (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' ) | ( (lv_operationParameterName_4_0= ruleOperationParameterName ) ) | ( (lv_classAttributeName_5_0= ruleClassAttributeName ) ) | this_INT_6= RULE_INT | this_STRING_7= RULE_STRING | ( (lv_set_8_0= ruleSet ) ) ) ) ;
    public final EObject ruleFactorExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token this_INT_6=null;
        Token this_STRING_7=null;
        EObject lv_expression_2_0 = null;

        EObject lv_operationParameterName_4_0 = null;

        EObject lv_classAttributeName_5_0 = null;

        EObject lv_set_8_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1741:2: ( ( () ( (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' ) | ( (lv_operationParameterName_4_0= ruleOperationParameterName ) ) | ( (lv_classAttributeName_5_0= ruleClassAttributeName ) ) | this_INT_6= RULE_INT | this_STRING_7= RULE_STRING | ( (lv_set_8_0= ruleSet ) ) ) ) )
            // InternalFinalDsl.g:1742:2: ( () ( (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' ) | ( (lv_operationParameterName_4_0= ruleOperationParameterName ) ) | ( (lv_classAttributeName_5_0= ruleClassAttributeName ) ) | this_INT_6= RULE_INT | this_STRING_7= RULE_STRING | ( (lv_set_8_0= ruleSet ) ) ) )
            {
            // InternalFinalDsl.g:1742:2: ( () ( (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' ) | ( (lv_operationParameterName_4_0= ruleOperationParameterName ) ) | ( (lv_classAttributeName_5_0= ruleClassAttributeName ) ) | this_INT_6= RULE_INT | this_STRING_7= RULE_STRING | ( (lv_set_8_0= ruleSet ) ) ) )
            // InternalFinalDsl.g:1743:3: () ( (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' ) | ( (lv_operationParameterName_4_0= ruleOperationParameterName ) ) | ( (lv_classAttributeName_5_0= ruleClassAttributeName ) ) | this_INT_6= RULE_INT | this_STRING_7= RULE_STRING | ( (lv_set_8_0= ruleSet ) ) )
            {
            // InternalFinalDsl.g:1743:3: ()
            // InternalFinalDsl.g:1744:4: 
            {
            if ( state.backtracking==0 ) {

              				current = forceCreateModelElement(
              					grammarAccess.getFactorExpressionAccess().getFactorExpressionAction_0(),
              					current);
              			
            }

            }

            // InternalFinalDsl.g:1750:3: ( (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' ) | ( (lv_operationParameterName_4_0= ruleOperationParameterName ) ) | ( (lv_classAttributeName_5_0= ruleClassAttributeName ) ) | this_INT_6= RULE_INT | this_STRING_7= RULE_STRING | ( (lv_set_8_0= ruleSet ) ) )
            int alt22=6;
            switch ( input.LA(1) ) {
            case 13:
                {
                alt22=1;
                }
                break;
            case 24:
                {
                alt22=2;
                }
                break;
            case 22:
                {
                alt22=3;
                }
                break;
            case RULE_INT:
                {
                alt22=4;
                }
                break;
            case RULE_STRING:
                {
                alt22=5;
                }
                break;
            case 27:
                {
                alt22=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }

            switch (alt22) {
                case 1 :
                    // InternalFinalDsl.g:1751:4: (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' )
                    {
                    // InternalFinalDsl.g:1751:4: (otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')' )
                    // InternalFinalDsl.g:1752:5: otherlv_1= '(' ( (lv_expression_2_0= ruleExpression ) ) otherlv_3= ')'
                    {
                    otherlv_1=(Token)match(input,13,FOLLOW_11); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_1, grammarAccess.getFactorExpressionAccess().getLeftParenthesisKeyword_1_0_0());
                      				
                    }
                    // InternalFinalDsl.g:1756:5: ( (lv_expression_2_0= ruleExpression ) )
                    // InternalFinalDsl.g:1757:6: (lv_expression_2_0= ruleExpression )
                    {
                    // InternalFinalDsl.g:1757:6: (lv_expression_2_0= ruleExpression )
                    // InternalFinalDsl.g:1758:7: lv_expression_2_0= ruleExpression
                    {
                    if ( state.backtracking==0 ) {

                      							newCompositeNode(grammarAccess.getFactorExpressionAccess().getExpressionExpressionParserRuleCall_1_0_1_0());
                      						
                    }
                    pushFollow(FOLLOW_12);
                    lv_expression_2_0=ruleExpression();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      							if (current==null) {
                      								current = createModelElementForParent(grammarAccess.getFactorExpressionRule());
                      							}
                      							set(
                      								current,
                      								"expression",
                      								lv_expression_2_0,
                      								"org.xtext.example.mydsl.FinalDsl.Expression");
                      							afterParserOrEnumRuleCall();
                      						
                    }

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      					newLeafNode(otherlv_3, grammarAccess.getFactorExpressionAccess().getRightParenthesisKeyword_1_0_2());
                      				
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:1781:4: ( (lv_operationParameterName_4_0= ruleOperationParameterName ) )
                    {
                    // InternalFinalDsl.g:1781:4: ( (lv_operationParameterName_4_0= ruleOperationParameterName ) )
                    // InternalFinalDsl.g:1782:5: (lv_operationParameterName_4_0= ruleOperationParameterName )
                    {
                    // InternalFinalDsl.g:1782:5: (lv_operationParameterName_4_0= ruleOperationParameterName )
                    // InternalFinalDsl.g:1783:6: lv_operationParameterName_4_0= ruleOperationParameterName
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFactorExpressionAccess().getOperationParameterNameOperationParameterNameParserRuleCall_1_1_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_operationParameterName_4_0=ruleOperationParameterName();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFactorExpressionRule());
                      						}
                      						set(
                      							current,
                      							"operationParameterName",
                      							lv_operationParameterName_4_0,
                      							"org.xtext.example.mydsl.FinalDsl.OperationParameterName");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:1801:4: ( (lv_classAttributeName_5_0= ruleClassAttributeName ) )
                    {
                    // InternalFinalDsl.g:1801:4: ( (lv_classAttributeName_5_0= ruleClassAttributeName ) )
                    // InternalFinalDsl.g:1802:5: (lv_classAttributeName_5_0= ruleClassAttributeName )
                    {
                    // InternalFinalDsl.g:1802:5: (lv_classAttributeName_5_0= ruleClassAttributeName )
                    // InternalFinalDsl.g:1803:6: lv_classAttributeName_5_0= ruleClassAttributeName
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFactorExpressionAccess().getClassAttributeNameClassAttributeNameParserRuleCall_1_2_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_classAttributeName_5_0=ruleClassAttributeName();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFactorExpressionRule());
                      						}
                      						set(
                      							current,
                      							"classAttributeName",
                      							lv_classAttributeName_5_0,
                      							"org.xtext.example.mydsl.FinalDsl.ClassAttributeName");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalFinalDsl.g:1821:4: this_INT_6= RULE_INT
                    {
                    this_INT_6=(Token)match(input,RULE_INT,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_INT_6, grammarAccess.getFactorExpressionAccess().getINTTerminalRuleCall_1_3());
                      			
                    }

                    }
                    break;
                case 5 :
                    // InternalFinalDsl.g:1826:4: this_STRING_7= RULE_STRING
                    {
                    this_STRING_7=(Token)match(input,RULE_STRING,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				newLeafNode(this_STRING_7, grammarAccess.getFactorExpressionAccess().getSTRINGTerminalRuleCall_1_4());
                      			
                    }

                    }
                    break;
                case 6 :
                    // InternalFinalDsl.g:1831:4: ( (lv_set_8_0= ruleSet ) )
                    {
                    // InternalFinalDsl.g:1831:4: ( (lv_set_8_0= ruleSet ) )
                    // InternalFinalDsl.g:1832:5: (lv_set_8_0= ruleSet )
                    {
                    // InternalFinalDsl.g:1832:5: (lv_set_8_0= ruleSet )
                    // InternalFinalDsl.g:1833:6: lv_set_8_0= ruleSet
                    {
                    if ( state.backtracking==0 ) {

                      						newCompositeNode(grammarAccess.getFactorExpressionAccess().getSetSetParserRuleCall_1_5_0());
                      					
                    }
                    pushFollow(FOLLOW_2);
                    lv_set_8_0=ruleSet();

                    state._fsp--;
                    if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      						if (current==null) {
                      							current = createModelElementForParent(grammarAccess.getFactorExpressionRule());
                      						}
                      						set(
                      							current,
                      							"set",
                      							lv_set_8_0,
                      							"org.xtext.example.mydsl.FinalDsl.Set");
                      						afterParserOrEnumRuleCall();
                      					
                    }

                    }


                    }


                    }
                    break;

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFactorExpression"


    // $ANTLR start "entryRuleSet"
    // InternalFinalDsl.g:1855:1: entryRuleSet returns [EObject current=null] : iv_ruleSet= ruleSet EOF ;
    public final EObject entryRuleSet() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSet = null;


        try {
            // InternalFinalDsl.g:1855:44: (iv_ruleSet= ruleSet EOF )
            // InternalFinalDsl.g:1856:2: iv_ruleSet= ruleSet EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getSetRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleSet=ruleSet();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleSet; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSet"


    // $ANTLR start "ruleSet"
    // InternalFinalDsl.g:1862:1: ruleSet returns [EObject current=null] : ( (lv_elementList_0_0= ruleElementList ) ) ;
    public final EObject ruleSet() throws RecognitionException {
        EObject current = null;

        EObject lv_elementList_0_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1868:2: ( ( (lv_elementList_0_0= ruleElementList ) ) )
            // InternalFinalDsl.g:1869:2: ( (lv_elementList_0_0= ruleElementList ) )
            {
            // InternalFinalDsl.g:1869:2: ( (lv_elementList_0_0= ruleElementList ) )
            // InternalFinalDsl.g:1870:3: (lv_elementList_0_0= ruleElementList )
            {
            // InternalFinalDsl.g:1870:3: (lv_elementList_0_0= ruleElementList )
            // InternalFinalDsl.g:1871:4: lv_elementList_0_0= ruleElementList
            {
            if ( state.backtracking==0 ) {

              				newCompositeNode(grammarAccess.getSetAccess().getElementListElementListParserRuleCall_0());
              			
            }
            pushFollow(FOLLOW_2);
            lv_elementList_0_0=ruleElementList();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              				if (current==null) {
              					current = createModelElementForParent(grammarAccess.getSetRule());
              				}
              				set(
              					current,
              					"elementList",
              					lv_elementList_0_0,
              					"org.xtext.example.mydsl.FinalDsl.ElementList");
              				afterParserOrEnumRuleCall();
              			
            }

            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSet"


    // $ANTLR start "entryRuleElementList"
    // InternalFinalDsl.g:1891:1: entryRuleElementList returns [EObject current=null] : iv_ruleElementList= ruleElementList EOF ;
    public final EObject entryRuleElementList() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElementList = null;


        try {
            // InternalFinalDsl.g:1891:52: (iv_ruleElementList= ruleElementList EOF )
            // InternalFinalDsl.g:1892:2: iv_ruleElementList= ruleElementList EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getElementListRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleElementList=ruleElementList();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleElementList; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElementList"


    // $ANTLR start "ruleElementList"
    // InternalFinalDsl.g:1898:1: ruleElementList returns [EObject current=null] : (otherlv_0= '((' ( (lv_expression_1_0= ruleExpression ) ) ( (lv_additionalExpression_2_0= ruleElementListExpression ) )* otherlv_3= '))' ) ;
    public final EObject ruleElementList() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_3=null;
        EObject lv_expression_1_0 = null;

        EObject lv_additionalExpression_2_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1904:2: ( (otherlv_0= '((' ( (lv_expression_1_0= ruleExpression ) ) ( (lv_additionalExpression_2_0= ruleElementListExpression ) )* otherlv_3= '))' ) )
            // InternalFinalDsl.g:1905:2: (otherlv_0= '((' ( (lv_expression_1_0= ruleExpression ) ) ( (lv_additionalExpression_2_0= ruleElementListExpression ) )* otherlv_3= '))' )
            {
            // InternalFinalDsl.g:1905:2: (otherlv_0= '((' ( (lv_expression_1_0= ruleExpression ) ) ( (lv_additionalExpression_2_0= ruleElementListExpression ) )* otherlv_3= '))' )
            // InternalFinalDsl.g:1906:3: otherlv_0= '((' ( (lv_expression_1_0= ruleExpression ) ) ( (lv_additionalExpression_2_0= ruleElementListExpression ) )* otherlv_3= '))'
            {
            otherlv_0=(Token)match(input,27,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getElementListAccess().getLeftParenthesisLeftParenthesisKeyword_0());
              		
            }
            // InternalFinalDsl.g:1910:3: ( (lv_expression_1_0= ruleExpression ) )
            // InternalFinalDsl.g:1911:4: (lv_expression_1_0= ruleExpression )
            {
            // InternalFinalDsl.g:1911:4: (lv_expression_1_0= ruleExpression )
            // InternalFinalDsl.g:1912:5: lv_expression_1_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getElementListAccess().getExpressionExpressionParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_26);
            lv_expression_1_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getElementListRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_1_0,
              						"org.xtext.example.mydsl.FinalDsl.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }

            // InternalFinalDsl.g:1929:3: ( (lv_additionalExpression_2_0= ruleElementListExpression ) )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==21) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalFinalDsl.g:1930:4: (lv_additionalExpression_2_0= ruleElementListExpression )
            	    {
            	    // InternalFinalDsl.g:1930:4: (lv_additionalExpression_2_0= ruleElementListExpression )
            	    // InternalFinalDsl.g:1931:5: lv_additionalExpression_2_0= ruleElementListExpression
            	    {
            	    if ( state.backtracking==0 ) {

            	      					newCompositeNode(grammarAccess.getElementListAccess().getAdditionalExpressionElementListExpressionParserRuleCall_2_0());
            	      				
            	    }
            	    pushFollow(FOLLOW_26);
            	    lv_additionalExpression_2_0=ruleElementListExpression();

            	    state._fsp--;
            	    if (state.failed) return current;
            	    if ( state.backtracking==0 ) {

            	      					if (current==null) {
            	      						current = createModelElementForParent(grammarAccess.getElementListRule());
            	      					}
            	      					add(
            	      						current,
            	      						"additionalExpression",
            	      						lv_additionalExpression_2_0,
            	      						"org.xtext.example.mydsl.FinalDsl.ElementListExpression");
            	      					afterParserOrEnumRuleCall();
            	      				
            	    }

            	    }


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

            otherlv_3=(Token)match(input,28,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_3, grammarAccess.getElementListAccess().getRightParenthesisRightParenthesisKeyword_3());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElementList"


    // $ANTLR start "entryRuleElementListExpression"
    // InternalFinalDsl.g:1956:1: entryRuleElementListExpression returns [EObject current=null] : iv_ruleElementListExpression= ruleElementListExpression EOF ;
    public final EObject entryRuleElementListExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElementListExpression = null;


        try {
            // InternalFinalDsl.g:1956:62: (iv_ruleElementListExpression= ruleElementListExpression EOF )
            // InternalFinalDsl.g:1957:2: iv_ruleElementListExpression= ruleElementListExpression EOF
            {
            if ( state.backtracking==0 ) {
               newCompositeNode(grammarAccess.getElementListExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            iv_ruleElementListExpression=ruleElementListExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {
               current =iv_ruleElementListExpression; 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return current;

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElementListExpression"


    // $ANTLR start "ruleElementListExpression"
    // InternalFinalDsl.g:1963:1: ruleElementListExpression returns [EObject current=null] : (otherlv_0= ',' ( (lv_expression_1_0= ruleExpression ) ) ) ;
    public final EObject ruleElementListExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        EObject lv_expression_1_0 = null;



        	enterRule();

        try {
            // InternalFinalDsl.g:1969:2: ( (otherlv_0= ',' ( (lv_expression_1_0= ruleExpression ) ) ) )
            // InternalFinalDsl.g:1970:2: (otherlv_0= ',' ( (lv_expression_1_0= ruleExpression ) ) )
            {
            // InternalFinalDsl.g:1970:2: (otherlv_0= ',' ( (lv_expression_1_0= ruleExpression ) ) )
            // InternalFinalDsl.g:1971:3: otherlv_0= ',' ( (lv_expression_1_0= ruleExpression ) )
            {
            otherlv_0=(Token)match(input,21,FOLLOW_11); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			newLeafNode(otherlv_0, grammarAccess.getElementListExpressionAccess().getCommaKeyword_0());
              		
            }
            // InternalFinalDsl.g:1975:3: ( (lv_expression_1_0= ruleExpression ) )
            // InternalFinalDsl.g:1976:4: (lv_expression_1_0= ruleExpression )
            {
            // InternalFinalDsl.g:1976:4: (lv_expression_1_0= ruleExpression )
            // InternalFinalDsl.g:1977:5: lv_expression_1_0= ruleExpression
            {
            if ( state.backtracking==0 ) {

              					newCompositeNode(grammarAccess.getElementListExpressionAccess().getExpressionExpressionParserRuleCall_1_0());
              				
            }
            pushFollow(FOLLOW_2);
            lv_expression_1_0=ruleExpression();

            state._fsp--;
            if (state.failed) return current;
            if ( state.backtracking==0 ) {

              					if (current==null) {
              						current = createModelElementForParent(grammarAccess.getElementListExpressionRule());
              					}
              					set(
              						current,
              						"expression",
              						lv_expression_1_0,
              						"org.xtext.example.mydsl.FinalDsl.Expression");
              					afterParserOrEnumRuleCall();
              				
            }

            }


            }


            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElementListExpression"


    // $ANTLR start "rulelibraryPersistenceMethodStatementEnum"
    // InternalFinalDsl.g:1998:1: rulelibraryPersistenceMethodStatementEnum returns [Enumerator current=null] : ( (enumLiteral_0= 'CreateInstance' ) | (enumLiteral_1= 'Log' ) ) ;
    public final Enumerator rulelibraryPersistenceMethodStatementEnum() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:2004:2: ( ( (enumLiteral_0= 'CreateInstance' ) | (enumLiteral_1= 'Log' ) ) )
            // InternalFinalDsl.g:2005:2: ( (enumLiteral_0= 'CreateInstance' ) | (enumLiteral_1= 'Log' ) )
            {
            // InternalFinalDsl.g:2005:2: ( (enumLiteral_0= 'CreateInstance' ) | (enumLiteral_1= 'Log' ) )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==29) ) {
                alt24=1;
            }
            else if ( (LA24_0==30) ) {
                alt24=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // InternalFinalDsl.g:2006:3: (enumLiteral_0= 'CreateInstance' )
                    {
                    // InternalFinalDsl.g:2006:3: (enumLiteral_0= 'CreateInstance' )
                    // InternalFinalDsl.g:2007:4: enumLiteral_0= 'CreateInstance'
                    {
                    enumLiteral_0=(Token)match(input,29,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLibraryPersistenceMethodStatementEnumAccess().getCreateInstanceEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLibraryPersistenceMethodStatementEnumAccess().getCreateInstanceEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:2014:3: (enumLiteral_1= 'Log' )
                    {
                    // InternalFinalDsl.g:2014:3: (enumLiteral_1= 'Log' )
                    // InternalFinalDsl.g:2015:4: enumLiteral_1= 'Log'
                    {
                    enumLiteral_1=(Token)match(input,30,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLibraryPersistenceMethodStatementEnumAccess().getLogEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLibraryPersistenceMethodStatementEnumAccess().getLogEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelibraryPersistenceMethodStatementEnum"


    // $ANTLR start "rulelibraryBusinessMethodStatementEnum"
    // InternalFinalDsl.g:2025:1: rulelibraryBusinessMethodStatementEnum returns [Enumerator current=null] : (enumLiteral_0= 'Hash' ) ;
    public final Enumerator rulelibraryBusinessMethodStatementEnum() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:2031:2: ( (enumLiteral_0= 'Hash' ) )
            // InternalFinalDsl.g:2032:2: (enumLiteral_0= 'Hash' )
            {
            // InternalFinalDsl.g:2032:2: (enumLiteral_0= 'Hash' )
            // InternalFinalDsl.g:2033:3: enumLiteral_0= 'Hash'
            {
            enumLiteral_0=(Token)match(input,31,FOLLOW_2); if (state.failed) return current;
            if ( state.backtracking==0 ) {

              			current = grammarAccess.getLibraryBusinessMethodStatementEnumAccess().getHashEnumLiteralDeclaration().getEnumLiteral().getInstance();
              			newLeafNode(enumLiteral_0, grammarAccess.getLibraryBusinessMethodStatementEnumAccess().getHashEnumLiteralDeclaration());
              		
            }

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelibraryBusinessMethodStatementEnum"


    // $ANTLR start "rulelibraryInterFaceMethodStatementEnum"
    // InternalFinalDsl.g:2042:1: rulelibraryInterFaceMethodStatementEnum returns [Enumerator current=null] : ( (enumLiteral_0= 'Message' ) | (enumLiteral_1= 'Error' ) ) ;
    public final Enumerator rulelibraryInterFaceMethodStatementEnum() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:2048:2: ( ( (enumLiteral_0= 'Message' ) | (enumLiteral_1= 'Error' ) ) )
            // InternalFinalDsl.g:2049:2: ( (enumLiteral_0= 'Message' ) | (enumLiteral_1= 'Error' ) )
            {
            // InternalFinalDsl.g:2049:2: ( (enumLiteral_0= 'Message' ) | (enumLiteral_1= 'Error' ) )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==32) ) {
                alt25=1;
            }
            else if ( (LA25_0==33) ) {
                alt25=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // InternalFinalDsl.g:2050:3: (enumLiteral_0= 'Message' )
                    {
                    // InternalFinalDsl.g:2050:3: (enumLiteral_0= 'Message' )
                    // InternalFinalDsl.g:2051:4: enumLiteral_0= 'Message'
                    {
                    enumLiteral_0=(Token)match(input,32,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLibraryInterFaceMethodStatementEnumAccess().getMessageEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getLibraryInterFaceMethodStatementEnumAccess().getMessageEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:2058:3: (enumLiteral_1= 'Error' )
                    {
                    // InternalFinalDsl.g:2058:3: (enumLiteral_1= 'Error' )
                    // InternalFinalDsl.g:2059:4: enumLiteral_1= 'Error'
                    {
                    enumLiteral_1=(Token)match(input,33,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getLibraryInterFaceMethodStatementEnumAccess().getErrorEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getLibraryInterFaceMethodStatementEnumAccess().getErrorEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelibraryInterFaceMethodStatementEnum"


    // $ANTLR start "ruleRelationalOperator"
    // InternalFinalDsl.g:2069:1: ruleRelationalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<>' ) | (enumLiteral_2= '<' ) | (enumLiteral_3= '=>' ) | (enumLiteral_4= '<=' ) | (enumLiteral_5= '=' ) | (enumLiteral_6= 'in' ) ) ;
    public final Enumerator ruleRelationalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:2075:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<>' ) | (enumLiteral_2= '<' ) | (enumLiteral_3= '=>' ) | (enumLiteral_4= '<=' ) | (enumLiteral_5= '=' ) | (enumLiteral_6= 'in' ) ) )
            // InternalFinalDsl.g:2076:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<>' ) | (enumLiteral_2= '<' ) | (enumLiteral_3= '=>' ) | (enumLiteral_4= '<=' ) | (enumLiteral_5= '=' ) | (enumLiteral_6= 'in' ) )
            {
            // InternalFinalDsl.g:2076:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<>' ) | (enumLiteral_2= '<' ) | (enumLiteral_3= '=>' ) | (enumLiteral_4= '<=' ) | (enumLiteral_5= '=' ) | (enumLiteral_6= 'in' ) )
            int alt26=7;
            switch ( input.LA(1) ) {
            case 34:
                {
                alt26=1;
                }
                break;
            case 35:
                {
                alt26=2;
                }
                break;
            case 36:
                {
                alt26=3;
                }
                break;
            case 37:
                {
                alt26=4;
                }
                break;
            case 38:
                {
                alt26=5;
                }
                break;
            case 39:
                {
                alt26=6;
                }
                break;
            case 40:
                {
                alt26=7;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }

            switch (alt26) {
                case 1 :
                    // InternalFinalDsl.g:2077:3: (enumLiteral_0= '>' )
                    {
                    // InternalFinalDsl.g:2077:3: (enumLiteral_0= '>' )
                    // InternalFinalDsl.g:2078:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,34,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getGreaterThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getRelationalOperatorAccess().getGreaterThanEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:2085:3: (enumLiteral_1= '<>' )
                    {
                    // InternalFinalDsl.g:2085:3: (enumLiteral_1= '<>' )
                    // InternalFinalDsl.g:2086:4: enumLiteral_1= '<>'
                    {
                    enumLiteral_1=(Token)match(input,35,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getUnequalToEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getRelationalOperatorAccess().getUnequalToEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:2093:3: (enumLiteral_2= '<' )
                    {
                    // InternalFinalDsl.g:2093:3: (enumLiteral_2= '<' )
                    // InternalFinalDsl.g:2094:4: enumLiteral_2= '<'
                    {
                    enumLiteral_2=(Token)match(input,36,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getSmallerThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getRelationalOperatorAccess().getSmallerThanEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalFinalDsl.g:2101:3: (enumLiteral_3= '=>' )
                    {
                    // InternalFinalDsl.g:2101:3: (enumLiteral_3= '=>' )
                    // InternalFinalDsl.g:2102:4: enumLiteral_3= '=>'
                    {
                    enumLiteral_3=(Token)match(input,37,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getGreaterOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_3, grammarAccess.getRelationalOperatorAccess().getGreaterOrEqualThanEnumLiteralDeclaration_3());
                      			
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalFinalDsl.g:2109:3: (enumLiteral_4= '<=' )
                    {
                    // InternalFinalDsl.g:2109:3: (enumLiteral_4= '<=' )
                    // InternalFinalDsl.g:2110:4: enumLiteral_4= '<='
                    {
                    enumLiteral_4=(Token)match(input,38,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getSmallerOrEqualThanEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_4, grammarAccess.getRelationalOperatorAccess().getSmallerOrEqualThanEnumLiteralDeclaration_4());
                      			
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalFinalDsl.g:2117:3: (enumLiteral_5= '=' )
                    {
                    // InternalFinalDsl.g:2117:3: (enumLiteral_5= '=' )
                    // InternalFinalDsl.g:2118:4: enumLiteral_5= '='
                    {
                    enumLiteral_5=(Token)match(input,39,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_5, grammarAccess.getRelationalOperatorAccess().getEqualToEnumLiteralDeclaration_5());
                      			
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalFinalDsl.g:2125:3: (enumLiteral_6= 'in' )
                    {
                    // InternalFinalDsl.g:2125:3: (enumLiteral_6= 'in' )
                    // InternalFinalDsl.g:2126:4: enumLiteral_6= 'in'
                    {
                    enumLiteral_6=(Token)match(input,40,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getRelationalOperatorAccess().getContainsEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_6, grammarAccess.getRelationalOperatorAccess().getContainsEnumLiteralDeclaration_6());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRelationalOperator"


    // $ANTLR start "ruleAdditionOperator"
    // InternalFinalDsl.g:2136:1: ruleAdditionOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= 'OR' ) ) ;
    public final Enumerator ruleAdditionOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:2142:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= 'OR' ) ) )
            // InternalFinalDsl.g:2143:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= 'OR' ) )
            {
            // InternalFinalDsl.g:2143:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= 'OR' ) )
            int alt27=3;
            switch ( input.LA(1) ) {
            case 41:
                {
                alt27=1;
                }
                break;
            case 42:
                {
                alt27=2;
                }
                break;
            case 43:
                {
                alt27=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 27, 0, input);

                throw nvae;
            }

            switch (alt27) {
                case 1 :
                    // InternalFinalDsl.g:2144:3: (enumLiteral_0= '+' )
                    {
                    // InternalFinalDsl.g:2144:3: (enumLiteral_0= '+' )
                    // InternalFinalDsl.g:2145:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,41,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAdditionOperatorAccess().getAdditionEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getAdditionOperatorAccess().getAdditionEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:2152:3: (enumLiteral_1= '-' )
                    {
                    // InternalFinalDsl.g:2152:3: (enumLiteral_1= '-' )
                    // InternalFinalDsl.g:2153:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,42,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAdditionOperatorAccess().getMinusEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getAdditionOperatorAccess().getMinusEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:2160:3: (enumLiteral_2= 'OR' )
                    {
                    // InternalFinalDsl.g:2160:3: (enumLiteral_2= 'OR' )
                    // InternalFinalDsl.g:2161:4: enumLiteral_2= 'OR'
                    {
                    enumLiteral_2=(Token)match(input,43,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getAdditionOperatorAccess().getOrOperatorEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getAdditionOperatorAccess().getOrOperatorEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdditionOperator"


    // $ANTLR start "ruleMultiplicationOperator"
    // InternalFinalDsl.g:2171:1: ruleMultiplicationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '*' ) | (enumLiteral_1= '/' ) | (enumLiteral_2= 'AND' ) ) ;
    public final Enumerator ruleMultiplicationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalFinalDsl.g:2177:2: ( ( (enumLiteral_0= '*' ) | (enumLiteral_1= '/' ) | (enumLiteral_2= 'AND' ) ) )
            // InternalFinalDsl.g:2178:2: ( (enumLiteral_0= '*' ) | (enumLiteral_1= '/' ) | (enumLiteral_2= 'AND' ) )
            {
            // InternalFinalDsl.g:2178:2: ( (enumLiteral_0= '*' ) | (enumLiteral_1= '/' ) | (enumLiteral_2= 'AND' ) )
            int alt28=3;
            switch ( input.LA(1) ) {
            case 44:
                {
                alt28=1;
                }
                break;
            case 45:
                {
                alt28=2;
                }
                break;
            case 46:
                {
                alt28=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return current;}
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // InternalFinalDsl.g:2179:3: (enumLiteral_0= '*' )
                    {
                    // InternalFinalDsl.g:2179:3: (enumLiteral_0= '*' )
                    // InternalFinalDsl.g:2180:4: enumLiteral_0= '*'
                    {
                    enumLiteral_0=(Token)match(input,44,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getMultiplicationOperatorAccess().getMultiplicationEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_0, grammarAccess.getMultiplicationOperatorAccess().getMultiplicationEnumLiteralDeclaration_0());
                      			
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalFinalDsl.g:2187:3: (enumLiteral_1= '/' )
                    {
                    // InternalFinalDsl.g:2187:3: (enumLiteral_1= '/' )
                    // InternalFinalDsl.g:2188:4: enumLiteral_1= '/'
                    {
                    enumLiteral_1=(Token)match(input,45,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getMultiplicationOperatorAccess().getDivisionEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_1, grammarAccess.getMultiplicationOperatorAccess().getDivisionEnumLiteralDeclaration_1());
                      			
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalFinalDsl.g:2195:3: (enumLiteral_2= 'AND' )
                    {
                    // InternalFinalDsl.g:2195:3: (enumLiteral_2= 'AND' )
                    // InternalFinalDsl.g:2196:4: enumLiteral_2= 'AND'
                    {
                    enumLiteral_2=(Token)match(input,46,FOLLOW_2); if (state.failed) return current;
                    if ( state.backtracking==0 ) {

                      				current = grammarAccess.getMultiplicationOperatorAccess().getAndEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                      				newLeafNode(enumLiteral_2, grammarAccess.getMultiplicationOperatorAccess().getAndEnumLiteralDeclaration_2());
                      			
                    }

                    }


                    }
                    break;

            }


            }

            if ( state.backtracking==0 ) {

              	leaveRule();

            }
        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMultiplicationOperator"

    // $ANTLR start synpred1_InternalFinalDsl
    public final void synpred1_InternalFinalDsl_fragment() throws RecognitionException {   
        // InternalFinalDsl.g:437:4: ( 'else' )
        // InternalFinalDsl.g:437:5: 'else'
        {
        match(input,18,FOLLOW_2); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_InternalFinalDsl

    // Delegated rules

    public final boolean synpred1_InternalFinalDsl() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_InternalFinalDsl_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x00000003E088A000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00000003E088A002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000003E088E000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000003EFC02050L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x00000003E08AA000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000104000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x00000003E0802000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000060000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000200002L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x000001FC00000002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x00000E0000000002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x00007003EFC02052L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x00007003EFC02050L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000009402050L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000010200000L});

}